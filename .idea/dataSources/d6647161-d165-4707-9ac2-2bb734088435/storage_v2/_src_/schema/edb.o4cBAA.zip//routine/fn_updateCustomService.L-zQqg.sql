create
    definer = proc@`%` function fn_updateCustomService(param_clientId int(8), sessionUser varchar(100),
                                                       param_asId int(8), param_bNum varchar(20),
                                                       param_asName varchar(50), param_asnotes varchar(200),
                                                       param_wpcId int(10), param_masterId int(10),
                                                       param_proxytag varchar(40), param_mnID int(10),
                                                       param_mntarget varchar(100), param_mntimeout int(4),
                                                       param_mntimezone int(4), param_mnrecord int(2),
                                                       param_emailsubject varchar(100), param_emailfrom varchar(100),
                                                       param_emailto varchar(255), param_emailcc varchar(255),
                                                       param_emailbcc varchar(255), param_mncustomVox int(2),
                                                       param_mnwishper varchar(50),
                                                       param_mntemplate varchar(50)) returns varchar(50) deterministic
BEGIN
DECLARE countad INT(5);
DECLARE countddispdnis INT(5);
DECLARE countdibdnis INT(5);
DECLARE checkadsource INT(5);

IF param_clientId <>'' THEN
	SET checkadsource = (SELECT COUNT(*) FROM adSource WHERE as_clientId=param_clientId AND as_adName= param_asName AND as_id!=param_asId);

	IF (checkadsource>0) THEN
		RETURN 'failedadsource';
	ELSE
		IF(param_mntemplate='')THEN
			SET param_mntemplate='autoattendant.html';
		END IF;

		IF(param_emailsubject='') THEN
			SET param_emailsubject = 'Missed Call. From [ani] to [bnum]';
		END IF;

		
		UPDATE  adSource  SET as_adName = param_asName,
							as_rlwpcID = param_wpcId,
							as_masterID = param_masterId,
							as_proxy = param_proxytag,
							as_notes =param_asnotes
		WHERE  as_id = param_asId AND as_clientId = param_clientId;

		
		UPDATE  menu  SET mn_target =  param_mntarget,
					mn_record =  param_mnrecord,
					mn_timeOut =  param_mntimeout,
					mn_timeZone = param_mntimezone,
					mn_subject = param_emailsubject,
					mn_emailFrom = param_emailfrom,
					mn_emailTo = param_emailto,
					mn_emailCc = param_emailcc,
					mn_emailBcc = param_emailbcc,
					mn_customVox = param_mncustomVox,
					mn_whisper =  param_mnwishper,
					mn_template = param_mntemplate
		WHERE  mn_id = param_mnID AND mn_clientId = param_clientId;

		INSERT INTO ws_auditTrail (at_dateTime, at_source, at_who, at_what, at_result, at_detail ) Values (now(), 3, sessionUser, param_clientId, 'Update Custom Service', param_bNum);

		RETURN  'success';
	END IF;
END IF;
END;

