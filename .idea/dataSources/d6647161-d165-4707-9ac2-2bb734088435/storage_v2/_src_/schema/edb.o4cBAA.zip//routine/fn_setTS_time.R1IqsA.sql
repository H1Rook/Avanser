create
    definer = proc@`%` function fn_setTS_time(clientId int, inFolder varchar(20), dow varchar(4), hrFrom time,
                                              hrThru time, fValue varchar(1)) returns varchar(20) deterministic
BEGIN
	DECLARE kount,julo,span INT;
	DECLARE todofrom, todothru INT;
	IF (fValue <'A' or fValue>'H') THEN
		RETURN 'Incorrect Value';
	END IF;
	SELECT count(*) INTO kount FROM timeSwitch
		    WHERE ts_clientId= clientId AND ts_folder = inFolder ;
	IF kount =0 THEN
		RETURN 'No such folder';
	END IF;
	SET todofrom = (select (hour(hrFrom) * 2) + (if(minute(hrFrom)>29,1,0)) + 1);
	SET todothru = (select (hour(hrThru) * 2) + (if(minute(hrThru)>29,1,0)) + 1);
	SET span = todothru - todofrom;
	CASE dow
		WHEN 'SUN' THEN
		UPDATE timeSwitch SET ts_W01 = insert(ts_W01, todofrom,span,repeat(UCASE(fValue),span)) WHERE ts_clientId= clientId AND ts_folder = inFolder;
		WHEN 'MON' THEN
		UPDATE timeSwitch SET ts_W02 = insert(ts_W02, todofrom,span,repeat(UCASE(fValue),span)) WHERE ts_clientId= clientId AND ts_folder = inFolder;
		WHEN 'TUE' THEN
		UPDATE timeSwitch SET ts_W03 = insert(ts_W03, todofrom,span,repeat(UCASE(fValue),span)) WHERE ts_clientId= clientId AND ts_folder = inFolder;
		WHEN 'WED' THEN
		UPDATE timeSwitch SET ts_W04 = insert(ts_W04, todofrom,span,repeat(UCASE(fValue),span)) WHERE ts_clientId= clientId AND ts_folder = inFolder;
		WHEN 'THU' THEN
		UPDATE timeSwitch SET ts_W05 = insert(ts_W05, todofrom,span,repeat(UCASE(fValue),span)) WHERE ts_clientId= clientId AND ts_folder = inFolder;
		WHEN 'FRI' THEN
		UPDATE timeSwitch SET ts_W06 = insert(ts_W06, todofrom,span,repeat(UCASE(fValue),span)) WHERE ts_clientId= clientId AND ts_folder = inFolder;
		WHEN 'SAT' THEN
		UPDATE timeSwitch SET ts_W07 = insert(ts_W07, todofrom,span,repeat(UCASE(fValue),span)) WHERE ts_clientId= clientId AND ts_folder = inFolder;
		WHEN 'SP1' THEN
		UPDATE timeSwitch SET ts_SP1 = insert(ts_SP1, todofrom,span,repeat(UCASE(fValue),span)) WHERE ts_clientId= clientId AND ts_folder = inFolder;
		WHEN 'SP2' THEN
		UPDATE timeSwitch SET ts_SP2 = insert(ts_SP2, todofrom,span,repeat(UCASE(fValue),span)) WHERE ts_clientId= clientId AND ts_folder = inFolder;
		WHEN 'SP3' THEN
		UPDATE timeSwitch SET ts_SP3 = insert(ts_SP3, todofrom,span,repeat(UCASE(fValue),span)) WHERE ts_clientId= clientId AND ts_folder = inFolder;
	ELSE
		RETURN 'Invalid Week day';
	END CASE;
	RETURN 'ok';
END;

