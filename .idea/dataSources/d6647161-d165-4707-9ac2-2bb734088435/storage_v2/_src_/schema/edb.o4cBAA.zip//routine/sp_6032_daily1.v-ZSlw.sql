create
    definer = proc@`%` procedure sp_6032_daily1(IN repDate date)
SELECT left(`cd_startTime`,16) as 'Start Time',
SEC_TO_TIME(`cd_callDuration`) as 'Duration',
CASE `cd_ani`
        WHEN '' then 'Private'
        ELSE `cd_ani` END as 'Calling Number',
if(cd_state='','&nbsp;',`cd_state`) as cd_state,
if(cd_location='','&nbsp;',`cd_location`) as cd_location,
cd_bnum as 'Dialed Number',
as_adName as 'Ad Source',
if(`cd_cp01`=0,'&nbsp;',`cd_cp01`) as cd_cp01,
if(`cd_cp02`=0,'&nbsp;',`cd_cp02`) as cd_cp02,
if(`cd_cp03`=0,'&nbsp;',`cd_cp03`) as cd_cp03,
if(`cd_cp04`=0,'&nbsp;',`cd_cp04`) as cd_cp04,
if(`cd_cp05`=0,'&nbsp;',`cd_cp05`) as cd_cp05,
if(`cd_cp06`=0,'&nbsp;',`cd_cp06`) as cd_cp06,
if(`cd_cp08`=0,'&nbsp;',`cd_cp08`) as cd_cp08,
CASE cd_callStatus
        WHEN 0 then 'Terminated'
        WHEN 1 then 'Connected'
        WHEN 2 then 'Busy'
        When 3 then 'Missed'
        WHEN 4 then 'Other'
        WHEN 5 then 'Answered'
        WHEN 6 then 'Fax'
        ELSE 'Other' END as 'Status',
CASE cd_recording
        When '' then '&nbsp;'
        ELSE concat('<a href=\"http://www.avanser.com.au/audio/sophie/autoattendant/',cd_folder,'/recordings/',cd_recording,'\">listen</a>')
        END as Recording,
CASE cd_message
        When '' then '&nbsp;'
        ELSE concat('<a href=\"http://www.avanser.com.au/audio/sophie/autoattendant/',cd_folder,'/messages/',cd_message,'\">listen</a>')
        END as Message
FROM `cdr`,`dispatcher`,`adSource`
WHERE `cd_startTime`> repDate
        and `cd_startTime` <  DATE_ADD(repDate, INTERVAL 1 DAY)
        and cd_clientid=6032
        and cd_bnum = dp_bnum
        and as_bnum = cd_bnum
        and cd_bnum <> '1800769637'
	and cd_ignore = '0'
order by `cd_startTime`;

