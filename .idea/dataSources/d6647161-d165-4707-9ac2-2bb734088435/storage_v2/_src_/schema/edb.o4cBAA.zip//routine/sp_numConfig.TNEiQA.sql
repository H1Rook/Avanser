create
    definer = proc@`%` procedure sp_numConfig(IN bnum varchar(25))
BEGIN
SELECT dp_bnum AS Number,as_rlwpcid AS WPCID ,as_adName AS AdName, mn_action AS Action,
	CASE mn_action
		WHEN 'e' THEN 'Exchange Based Routing'
		WHEN 'l' THEN  'Exchange Based Routing'
		WHEN 'o' THEN 'Offline - Non RealTime'
		WHEN 'p' THEN 'Prompt Service'
		WHEN 'r' THEN 'Post Code Prompting'
		WHEN's' THEN 'Interactive Voice Response'
		WHEN 't' THEN 'Time Based Routing'
		WHEN'v' THEN 'Voice Mail'
		WHEN'x' THEN 'Simple Transfer'
		ELSE 'Other'
	END AS Routing
FROM menu
	JOIN dispatcher on mn_parent=0 and mn_item=-1 and mn_folder=dp_folder
	JOIN adSource on dp_bnum=as_bnum where dp_bnum=bnum;
END;

