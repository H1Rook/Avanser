create
    definer = proc@`%` function fn_createVMService(clientId_param char(255), country_param char(255),
                                                   friendlyname_param char(255),
                                                   emailTo_param char(255)) returns varchar(20) deterministic
BEGIN
	DECLARE confFolder	char(255);
	DECLARE confGreeting	char(255);
	DECLARE confTemplate	char(255);
	DECLARE confSubject	char(255);
	DECLARE confHost  	char(255);
	DECLARE confdnis 		char(255);
	DECLARE confIBNumber char(255);
	DECLARE confIBId		 char(255);
	DECLARE confScript 	char(255);
	DECLARE confMNFolder char(255);
		SET confIBNumber = (SELECT Number FROM inbound WHERE `type`= country_param AND (Client_ID='5001')  AND (Decommissioned is Null) LIMIT 1,1);
		SET confIBId = (SELECT ID FROM inbound WHERE Number = confIBNumber);
		IF (confIBNumber != '') THEN
			SET confFolder = (SELECT max(mn_folder)+1 FROM menu WHERE mn_clientId=clientId_param and mn_folder BETWEEN 60000000  AND 70000000 );
			IF isNULL(confFolder) THEN
            			SET confFolder = (SELECT concat(clientId_param,'0001'));
        		END IF;
			SET confGreeting = 'not_available.wav';
			SET confTemplate = 'autoattendant.html';
			SET confSubject = 'FreeNum Service';
			INSERT INTO menu ( mn_clientId, mn_folder, mn_parent, mn_item, mn_dtmfName,
						mn_action, mn_noWait,
						mn_customVox, mn_greeting, mn_subject, mn_emailTo, mn_template)
			VALUES (clientId_param, confFolder, 0, -1, friendlyname_param,
						'v', 1,
						0, confGreeting, confSubject, emailTo_param, confTemplate);
			SET confHost 	= ( SELECT AVANSER_ref FROM inbound WHERE  ID = confIBId );
			SET confdnis 	= ( SELECT Terminating_No FROM inbound WHERE  ID = confIBId );
			SET confScript = 'autoattendent';
			UPDATE inbound SET Client_ID = clientId_param ,
					  Terminating_Service = friendlyname_param,
					  Requested	= NOW(),
					  Provisioned	= NOW(),
					  Decommissioned = NULL
				WHERE	ID = confIBId;
			INSERT INTO dispatcher (dp_clientId, dp_bnum, dp_dnis, dp_host, dp_script, dp_folder, dp_comments )
				   VALUES (clientId_param, confIBNumber, confdnis, confHost, confScript, confFolder, friendlyname_param);
			INSERT INTO adSource (as_clientId , as_adName, as_bnum, as_cost, as_campaignStart)
				   VALUES (clientId_param, friendlyname_param, confIBNumber , 1, NOW());
			INSERT INTO portal_clientbnum (cb_clientId, cb_bnum, cb_clientIdx, cb_accessflag)
				   VALUES (clientId_param, confIBNumber, clientId_param, '9999');
			INSERT INTO ws_auditTrail (at_dateTime, at_source, at_who, at_what, at_result, at_detail ) Values (now(), 3, 'web form', clientId_param, 'FreeNum Service - New Number', confIBNumber);
			RETURN confIBNumber;
		ELSE
			RETURN 0;
		END IF;
END;

