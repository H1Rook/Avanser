create
    definer = proc@`%` procedure sp_wklyUniqueCallers(IN clientid int, IN timeout int) deterministic
BEGIN
SET @wk= date_format(now(), '%u')-1;
SELECT
	CONCAT('<tr><td>',`as_adName`,'</td><td align="right">',count(distinct `cd_cutamper`),'</td></tr>')
FROM	`adSource` LEFT JOIN `cdr`
	ON	`as_adName`=`cd_adName`
		AND `cd_startTime`>date_sub(now(),interval 15 day)
		AND date_format(`cd_startTime`,'%u')= @wk
		AND `cd_callduration`>timeout where `as_clientId`=clientid
GROUP BY `as_adName`
ORDER BY `as_adName`;
END;

