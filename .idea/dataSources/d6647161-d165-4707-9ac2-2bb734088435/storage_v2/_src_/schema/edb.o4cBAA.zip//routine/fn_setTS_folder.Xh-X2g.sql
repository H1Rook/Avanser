create
    definer = proc@`%` function fn_setTS_folder(clientId int, inFolder varchar(20), fToken varchar(1),
                                                fValue varchar(20)) returns varchar(20) deterministic
BEGIN
	DECLARE kount INT;
	IF (fToken <'A' or fToken>'H') THEN
		RETURN 'Incorrect Value';
	END IF;
	SELECT count(*) INTO kount FROM timeSwitch
		    WHERE ts_clientId= clientId AND ts_folder = inFolder ;
	IF kount =0 THEN
		RETURN 'No such folder';
	END IF;
	CASE fToken
		WHEN 'A' THEN
		UPDATE timeSwitch SET ts_folderA = fValue WHERE ts_clientId= clientId AND ts_folder = inFolder;
		WHEN 'B' THEN
		UPDATE timeSwitch SET ts_folderB = fValue WHERE ts_clientId= clientId AND ts_folder = inFolder;
		WHEN 'C' THEN
		UPDATE timeSwitch SET ts_folderC = fValue WHERE ts_clientId= clientId AND ts_folder = inFolder;
		WHEN 'D' THEN
		UPDATE timeSwitch SET ts_folderD = fValue WHERE ts_clientId= clientId AND ts_folder = inFolder;
		WHEN 'E' THEN
		UPDATE timeSwitch SET ts_folderE = fValue WHERE ts_clientId= clientId AND ts_folder = inFolder;
		WHEN 'F' THEN
		UPDATE timeSwitch SET ts_folderF = fValue WHERE ts_clientId= clientId AND ts_folder = inFolder;
		WHEN 'G' THEN
		UPDATE timeSwitch SET ts_folderG = fValue WHERE ts_clientId= clientId AND ts_folder = inFolder;
		WHEN 'H' THEN
		UPDATE timeSwitch SET ts_folderH = fValue WHERE ts_clientId= clientId AND ts_folder = inFolder;
	ELSE
		RETURN 'Invalid Token';
	END CASE;
	RETURN 'ok';
END;

