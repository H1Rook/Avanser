create
    definer = proc@`%` procedure sp_daily_by_flag(IN clientId int(6), IN accessFlag int(4))
SELECT
	`cd_localTime` as 'Start Time',
	SEC_TO_TIME(`cd_callDuration`) as 'Duration',
	CASE `cd_ani`
        	WHEN '' then 'Private'
	        ELSE fn_cleanNum(`cd_ani`,'','')
	 END as 'Calling Number',
	fn_cleanNum(`cd_bnum`,'','') as 'Dialed Number',
	`cd_adName` as 'Ad Source',
	CASE `cd_callStatus`
        	WHEN 0 then 'Missed'
	        WHEN 1 then 'Connected'
	        WHEN 2 then 'Busy'
        	When 3 then 'Missed'
	        ELSE 'Other' END as 'Status'
FROM `cdr`
WHERE `cd_localTime` between DATE_SUB(CURDATE(), INTERVAL 1 DAY)AND CURDATE()
        	AND `cd_clientId`= clientId
		AND `cd_bnum` in (SELECT DISTINCT `cb_bnum` FROM `portal_clientbnum` WHERE `cb_clientIdx`=clientId AND `cb_accessFlag`= accessFlag)
		AND `cd_ignore` = 0
ORDER BY `cd_localTime`;

