create
    definer = root@`%` function fn_getXCHG2(telNumber varchar(50), country varchar(2)) returns varchar(20) deterministic
BEGIN
   DECLARE MCHLGD VARCHAR(255);
   IF (country = 'AU') THEN
      IF (LEFT(telNumber,1) = '+') THEN
         SET telNumber = CONCAT('61',SUBSTRING(telNumber,6));
      END IF;
      SET MCHLGD = (SELECT av_id FROM xchg_AU WHERE av_Ref = (SELECT cli_avRef FROM cli_AU where telNumber like CONCAT(cli_prefix,'%') ORDER BY cli_prefixLen DESC limit 1) limit 1);
   END IF;
   IF (country = 'NZ') THEN
      IF (LEFT(telNumber,1) = '+') THEN
         SET telNumber = SUBSTRING(telNumber,6);
      END IF;
      IF (LEFT(telNumber,1) = '0') THEN
         SET telNumber = SUBSTRING(telNumber,2);
      END IF;
      SET MCHLGD = (SELECT av_id FROM xchg_NZ WHERE av_Ref = (SELECT cli_avRef FROM cli_NZ where telNumber like CONCAT(cli_prefix,'%') ORDER BY cli_prefixLen DESC limit 1) limit 1);
   END IF;
   IF (country = 'MY') THEN
      IF (LEFT(telNumber,1) = '+') THEN
         SET telNumber = CONCAT('60',SUBSTRING(telNumber,6));
      END IF;
      SET MCHLGD = (SELECT av_id FROM xchg_MY WHERE av_Ref = (SELECT cli_avRef FROM cli_MY where telNumber like CONCAT(cli_prefix,'%') ORDER BY cli_prefixLen DESC limit 1) limit 1);
   END IF;
  IF (ISNULL(MCHLGD) OR MCHLGD = '') THEN
	RETURN 0;
  END IF;
  RETURN  MCHLGD;
END;

