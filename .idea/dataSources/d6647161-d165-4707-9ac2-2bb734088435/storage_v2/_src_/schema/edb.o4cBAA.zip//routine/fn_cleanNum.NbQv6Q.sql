create
    definer = proc@`%` function fn_cleanNum(number varchar(30), mode varchar(20), cutamper varchar(30)) returns varchar(30)
    deterministic
BEGIN
	
	DECLARE ret VARCHAR(30);
	SET ret = NULL;
	
	IF ( number REGEXP ('^\\+[0-9]{1,3}\\-Private$') )
	THEN
		SET ret = 'Private';
	ELSEIF ( number REGEXP ('^\\+[0-9]{1,3}\\-VIRT[0-9]{3,18}$') )
	THEN
		SET ret = SUBSTRING_INDEX(number, '-', -1);
	ELSEIF ( number REGEXP ('^\\+[0-9]{1,3}\\-[0-9]{6,18}$') )
	THEN
		
		if ( mode = 'INTERNATIONAL' )
		THEN
			
			SET ret = SUBSTRING_INDEX(SUBSTRING(number,2), '-', 1);
			IF ( SUBSTRING(SUBSTRING_INDEX(number, '-', -1), 1,1) = '0' )
			THEN
				
				SET ret = CONCAT( ret , SUBSTRING(SUBSTRING_INDEX(number, '-', -1), 2) );
			ELSE
				
				SET ret = CONCAT( ret , SUBSTRING_INDEX(number, '-', -1) );
			END IF;
			
		ELSE
			
			SET ret = SUBSTRING_INDEX(number, '-', -1);
			
		END IF;
		
	ELSE
		
		SET ret = number;
		
	END IF;
	
	
	IF ( cutamper != '' AND ret = 'Private')
	THEN
		SET ret = CONCAT('Private-Ref:', cutamper);
	END IF;
	
	
	RETURN ret;
	
END;

