create
    definer = proc@`%` function fn_getXCHG(telNumber varchar(50)) returns varchar(20) deterministic
BEGIN
	DECLARE x  INT;
	DECLARE MCHLGD VARCHAR(255);
        SET x = 12;
	WHILE x  >= 3 DO
		SET MCHLGD =(SELECT av_id FROM ebr_xchg WHERE av_Ref = (SELECT cli_avRef FROM ebr_cli WHERE cli_prefix =SUBSTRING(telNumber,1,x) limit 1) limit 1);
		 IF  ( MCHLGD != null OR MCHLGD!='') THEN
			SET  x = 0;
			RETURN  MCHLGD;
		ELSE
			SET  x = x - 1;
		END IF;
	END WHILE;
	RETURN 0;
END;

