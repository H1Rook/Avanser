create
    definer = proc@`%` function fn_updateService(param_clientId int(8), param_userId varchar(100), param_asId int(8),
                                                 param_bNum varchar(20), param_asName varchar(50),
                                                 param_tagName varchar(40), param_cost float, param_campDate date,
                                                 param_decommDate date, param_rateType varchar(8),
                                                 param_folder varchar(20), param_cfna varchar(20),
                                                 param_billsource varchar(10), param_status varchar(50),
                                                 param_provider varchar(30), param_mnID int(10),
                                                 param_dnisterm varchar(20), param_wpcId int(10),
                                                 param_masterId int(10), param_region varchar(50)) returns varchar(50)
    deterministic
BEGIN
DECLARE countad INT(5);
DECLARE countddispdnis INT(5);
DECLARE countdibdnis INT(5);
IF param_clientId <>'' THEN
	SET countddispdnis = (SELECT count(*) FROM dispatcher WHERE dp_dnis = param_dnisterm);
	SET countdibdnis = (SELECT count(*) FROM dispatcher WHERE dp_dnis = param_dnisterm);
		UPDATE  adSource  SET as_adName = param_asName ,
						as_cost = param_cost ,
						as_proxy =  param_tagName,
						as_campaignStart =  param_campDate,
						as_rlwpcID = param_wpcId,
						as_masterID = param_masterId
		WHERE  as_id = param_asId AND as_clientId = param_clientId;
		IF(param_rateType <> '') THEN
			UPDATE  inbound  SET Type = param_rateType
			WHERE  Client_ID = param_clientId AND Number = param_bNum;
		END IF;
		UPDATE  inbound  SET CFNA = param_cfna,
							Bill_source = param_billsource,
							Region = param_region,
							Status = param_status,
							Provider = param_provider,
							Provisioned = param_campDate
		WHERE  Client_ID = param_clientId AND Number = param_bNum;
		UPDATE dispatcher SET dp_folder = param_folder
		WHERE dp_clientId = param_clientId AND dp_bnum = param_bNum;
		IF countddispdnis=0 and countdibdnis=0 THEN
			UPDATE  inbound  SET Terminating_No = param_dnisterm
				WHERE  Client_ID = param_clientId AND Number = param_bNum AND Decommissioned IS NULL;
			UPDATE dispatcher SET dp_dnis = param_dnisterm
				WHERE dp_clientId = param_clientId AND dp_bnum = param_bNum;
		END IF;
		INSERT INTO ws_auditTrail (at_dateTime, at_source, at_who, at_what, at_result, at_detail )
		Values (now(), 3, param_userId , param_clientId, 'Update Adsource Details' , CONCAT('Update Adsource Details',' FOLDER- ',param_folder,' AdSource- ',param_asName,' BNUM- ',param_bNum, 'Region - ', param_region));
	SET countad = (SELECT count(*) FROM adSource WHERE as_clientId = param_clientId AND as_adName = param_asName);
	IF (countad > 0) THEN
		RETURN param_bNum;
	ELSE
		RETURN 'failed';
	END IF;
END IF;
END;

