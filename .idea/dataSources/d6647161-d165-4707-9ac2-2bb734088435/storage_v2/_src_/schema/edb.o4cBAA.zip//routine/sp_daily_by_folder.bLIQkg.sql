create
    definer = root@`%` procedure sp_daily_by_folder(IN folder varchar(20), IN YYYYMMDD int)
SELECT
  DATE_FORMAT(`cd_localTime`,'%d %b %Y %H:%i') as 'Start Time'
  ,fn_cleanNum(`cd_ani`,'',`cd_cutamper`) as 'Calling Number'
  ,`cd_location` as 'Location'
  ,`cd_adName` as 'Ad Source Name'
  ,fn_cleanNum(`cd_bnum`,'','') as 'Dialed Number'
  ,CASE	`cd_callStatus`
        WHEN 1 then 'Answered'
        WHEN 2 then 'Busy'
        ELSE 'Missed' END as 'Status'
  ,SEC_TO_TIME(`cd_callDuration`) as 'Duration'
  From `cdr` where `cd_folder`=folder and `cd_localTime` between date_sub(CURDATE(), INTERVAL 1 DAY)AND CURDATE()
order by `cd_localTime`;

