create
    definer = proc@`%` function fn_getTimeCode(telNumber varchar(50), LOCALCOUNTRY varchar(2)) returns varchar(255)
    deterministic
BEGIN
   DECLARE x  INT;
   DECLARE TIMECODE VARCHAR(5);
   DECLARE COUNTRYSTATE VARCHAR(255);
   IF (telNumber REGEXP '\\+[0-9]{1,3}\\-[0-9]{6,12}$') THEN
       IF (SUBSTRING_INDEX(telNumber,'-',1)='+61') THEN
           SET LOCALCOUNTRY = 'AU';
       END IF;
       IF (SUBSTRING_INDEX(telNumber,'-',1)='+64') THEN
           SET LOCALCOUNTRY = 'NZ';
       END IF;
       IF (SUBSTRING_INDEX(telNumber,'-',1)='+60') THEN
           SET LOCALCOUNTRY = 'MY';
       END IF;
       IF (SUBSTRING_INDEX(telNumber,'-',1)='+44') THEN
           SET LOCALCOUNTRY = 'UK';
       END IF;
       IF (SUBSTRING_INDEX(telNumber,'-',1)='+65') THEN
           SET LOCALCOUNTRY = 'SG';
       END IF;
       SET telNumber = SUBSTRING_INDEX(telNumber,'-',-1);
   END IF;
   IF (LOCALCOUNTRY != 'AU') THEN
       SET TIMECODE =(SELECT tz_code FROM timeZone WHERE tz_country=LOCALCOUNTRY LIMIT 1);
       IF  ( TIMECODE != null OR TIMECODE!='') THEN
           RETURN TIMECODE;
       END IF;
   ELSE
       SET x = 12;
       WHILE x  >= 3 DO
           IF (LOCALCOUNTRY = 'AU') THEN
               SET COUNTRYSTATE =(SELECT av_state FROM xchg_AU WHERE av_Ref = (SELECT cli_avRef FROM cli_AU WHERE cli_prefix =CONCAT('61',SUBSTRING(telNumber,2,x)) limit 1) limit 1);
           END IF;
           IF  ( COUNTRYSTATE != null OR COUNTRYSTATE!='') THEN
               SET x = 0;
               SET TIMECODE =(SELECT tz_code FROM timeZone WHERE tz_country=LOCALCOUNTRY AND tz_state=COUNTRYSTATE LIMIT 1);
               IF  ( TIMECODE != null OR TIMECODE!='') THEN
                   RETURN TIMECODE;
               END IF;
           ELSE
               SET  x = x - 1;
           END IF;
         END WHILE;
   END IF;
   RETURN 0;
END;

