create
    definer = proc@`%` procedure sp_6032_daily2(IN repDate date)
BEGIN
IF (repDate = 0) THEN
	set @DATE = DATE_SUB(CURDATE(), INTERVAL 1 DAY);
ELSE
	set @DATE = repDate;
END IF;
SELECT left(`cd_startTime`,16) as 'Start Time',
SEC_TO_TIME(`cd_callDuration`) as 'Duration',
CASE `cd_ani`
        WHEN '' then 'Private'
        ELSE `cd_ani` END as 'Calling Number',
cd_state,cd_location,
cd_bnum as 'Dialed Number',
as_adName as 'Ad Source',
CASE cd_callStatus
        WHEN 0 then 'Abandoned'
        WHEN 1 then 'Connected'
        WHEN 2 then 'Busy'
        When 3 then 'Missed'
	When 4 then 'Other'
	When 5 then 'Handled'
	When 6 then 'FAX'
        ELSE 'Other' END as 'Status'
FROM `cdr`,`dispatcher`,`adSource`
WHERE `cd_startTime`> @DATE
        and `cd_startTime`< DATE_ADD(@DATE, INTERVAL 1 DAY)
        and cd_clientid=6032
        and cd_bnum = dp_bnum
        and as_bnum = cd_bnum
        and cd_bnum = '1800769637'
order by `cd_startTime`;
END;

