create
    definer = proc@`%` procedure sp_monthly_by_postCode(IN clientid int(8), IN YYYYMM int(6))
SELECT
CASE `cd_cp08`
WHEN '' THEN 'No Post Code entered'
ELSE `cd_cp08`END as 'Post Code',
`cd_branch` as 'Branch',
COUNT(*) as 'Calls' FROM `cdr` WHERE
`cd_clientId`= clientid
AND
EXTRACT(YEAR_MONTH from `cd_startTime`) = YYYYMM
GROUP BY `cd_cp08`
ORDER BY Calls DESC;

