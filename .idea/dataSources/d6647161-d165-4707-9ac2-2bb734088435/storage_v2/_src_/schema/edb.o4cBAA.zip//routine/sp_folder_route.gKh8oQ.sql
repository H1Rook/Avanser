create
    definer = proc@`%` procedure sp_folder_route(IN mode_param varchar(15), IN id_param varchar(20),
                                                 IN serviceaction_param varchar(5), IN clientId_param int,
                                                 IN folder_param varchar(20), IN parent_param int,
                                                 IN item_param varchar(2), IN answerpointname_param varchar(40),
                                                 IN route_param varchar(15), IN defaultfolder_param varchar(40),
                                                 IN target_param varchar(100), IN forward_param varchar(30),
                                                 IN clid_param varchar(20), IN customvox_param int,
                                                 IN greeting_param varchar(40), IN subject_param varchar(100),
                                                 IN emailfrom_param varchar(100), IN emailto_param varchar(255),
                                                 IN emailcc_param varchar(255), IN emailbcc_param varchar(255),
                                                 IN template_param varchar(50), IN mobile_param varchar(50),
                                                 IN sms_param varchar(20), IN whisper_param varchar(50),
                                                 IN prompt_param varchar(100), IN submenu_param int,
                                                 IN notifyall_param int, IN record_param int, IN timeout_param int,
                                                 IN timezone_param int, IN ap_param int, IN auxfolder_param varchar(20),
                                                 IN nowait_param int, IN ignore_param int,
                                                 IN sessionUser_param varchar(50))
BEGIN
DECLARE checkfolder VARCHAR(20);
IF mode_param ='add' THEN
		IF (item_param<0) THEN
			SET checkfolder = (SELECT COUNT(*) FROM menu WHERE mn_clientId=clientId_param AND mn_folder=folder_param);
		ELSE
			SET checkfolder = 0;
		END IF;
		IF checkfolder=0 THEN
			IF serviceaction_param ='xfr'  OR serviceaction_param ='x' THEN
				IF submenu_param='' THEN
					Set submenu_param = 0;
				END IF;
			ELSE
				SET whisper_param = REPLACE(whisper_param,'.wav','');
				SET prompt_param = REPLACE(prompt_param,'.wav','');
			END IF;
			INSERT INTO menu (mn_clientId, mn_folder, mn_parent, mn_item, mn_dtmfName, mn_action, mn_noWait, mn_route, mn_default, mn_target, mn_forward, mn_clid, mn_customVox, mn_greeting,
						mn_subject, mn_emailFrom, mn_emailTo, mn_emailCc, mn_emailBcc, mn_template, mq_mobile, mn_sms, mn_whisper, mn_prompt, mn_submenu, mn_notifyAll, mn_record, mn_timeOut,
						mn_timeZone, mn_ap, mn_auxFolder, mn_ignore)
			VALUES(clientId_param, folder_param, parent_param, item_param, answerpointname_param, serviceaction_param , nowait_param, route_param, defaultfolder_param, target_param, forward_param,clid_param,
					customvox_param, greeting_param, subject_param, emailfrom_param, emailto_param, emailcc_param, emailbcc_param, template_param, mobile_param, sms_param, whisper_param,
					prompt_param, submenu_param, notifyall_param, record_param, timeout_param, timezone_param, ap_param, auxfolder_param, ignore_param);
			INSERT INTO ws_auditTrail (at_dateTime, at_source, at_who, at_what, at_result, at_detail ) Values (now(), 3, sessionUser_param, clientId_param, 'Create New Folder', folder_param);
		END IF;
END IF;
IF mode_param ='edit' THEN
		IF serviceaction_param != 'xfr'  OR serviceaction_param != 'x'  THEN
			SET whisper_param = REPLACE(whisper_param,'.wav','');
			SET prompt_param = REPLACE(prompt_param,'.wav','');
		END IF;
		UPDATE menu
			SET 	mn_clientId=clientId_param,
				mn_folder= folder_param,
				mn_parent= parent_param,
				mn_item= item_param,
				mn_dtmfName= answerpointname_param,
				mn_action= serviceaction_param,
				mn_route= route_param,
				mn_default= defaultfolder_param,
				mn_target= target_param,
				mn_forward= forward_param,
				mn_clid= clid_param,
				mn_customVox= customvox_param,
				mn_greeting=greeting_param,
				mn_subject= subject_param,
				mn_emailFrom = emailfrom_param,
				mn_emailTo= emailto_param,
				mn_emailCc= emailcc_param,
				mn_emailBcc= emailbcc_param,
				mn_template= template_param,
				mq_mobile= mobile_param,
				mn_sms= sms_param,
				mn_whisper= whisper_param,
				mn_prompt= prompt_param,
				mn_submenu= submenu_param,
				mn_notifyAll= notifyall_param,
				mn_record= record_param,
				mn_timeOut=timeout_param,
				mn_timeZone= timezone_param,
				mn_ap= ap_param,
				mn_auxFolder= auxfolder_param,
				mn_noWait= nowait_param,
				mn_ignore=ignore_param
		WHERE mn_id=id_param AND mn_clientId=clientId_param ;
		INSERT INTO ws_auditTrail (at_dateTime, at_source, at_who, at_what, at_result, at_detail ) Values (now(), 3, sessionUser_param, clientId_param, 'Update Folder', folder_param);
END IF;
END;

