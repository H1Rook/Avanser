create
    definer = proc@`%` procedure sp_deleteVMService(IN clientId_param char(255))
BEGIN
	DELETE from portal_clientbnum WHERE cb_clientId = clientId_param;
	DELETE from adSource WHERE as_clientId = clientId_param;
	DELETE  from dispatcher WHERE dp_clientId = clientId_param;
	UPDATE inbound SET Client_ID = '5001', Requested=NULL
			WHERE Client_ID= clientId_param;
	DELETE from menu WHERE mn_clientId = clientId_param;
END;

