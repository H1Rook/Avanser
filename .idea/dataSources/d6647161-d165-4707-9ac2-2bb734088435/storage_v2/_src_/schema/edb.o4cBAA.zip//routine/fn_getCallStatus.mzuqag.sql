create
    definer = proc@`%` function fn_getCallStatus(cd_callStatus varchar(10)) returns varchar(20) deterministic
BEGIN
	DECLARE callStatus VARCHAR(100);
	IF(cd_callStatus='1')THEN
	 	SET callStatus='Answered';
	ELSEIF(cd_callStatus='6')THEN
	 	SET callStatus='Fax';
	ELSE
		SET callStatus='Missed';
	END IF;
	RETURN callStatus;
END;

