create
    definer = proc@`%` function fn_setTS_date(clientId int(8), inFolder varchar(20), inDate date,
                                              inValue int(4)) returns varchar(20) deterministic
BEGIN
	DECLARE kount,julo INT;
	IF (inValue <0 or inValue>3) THEN
		RETURN 'Incorrect Value';
	END IF;
	SELECT count(*) INTO kount FROM timeSwitch
		    WHERE ts_clientId= clientId AND ts_folder = inFolder ;
	IF kount =0 THEN
		RETURN 'No such folder';
	END IF;
	SET julo = (select date_format(inDate,"%j"));
	CASE YEAR(inDate)
		WHEN 2010 THEN
			UPDATE timeSwitch set ts_Y2010 = insert(ts_Y2010,julo,1,inValue) WHERE ts_clientId= clientId AND ts_folder = inFolder ;
		WHEN 2011 THEN
			UPDATE timeSwitch set ts_Y2011 = insert(ts_Y2011,julo,1,inValue) WHERE ts_clientId= clientId AND ts_folder = inFolder ;
	ELSE
		RETURN 'Incorrect Year';
	END CASE;
	RETURN 'ok';
END;

