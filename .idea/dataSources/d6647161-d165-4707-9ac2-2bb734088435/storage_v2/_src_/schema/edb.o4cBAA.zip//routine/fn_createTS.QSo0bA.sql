create
    definer = proc@`%` function fn_createTS(clientId int, inFolder varchar(20), tsName varchar(40),
                                            timeZone int) returns varchar(20) deterministic
BEGIN
	DECLARE kount INT;
	SELECT count(*) INTO kount FROM timeSwitch
		    WHERE ts_clientId= clientId AND ts_folder = inFolder ;
	IF kount >0 THEN
		RETURN 'Error: folder exists!';
	ELSE
		INSERT INTO timeSwitch (`ts_clientId`, `ts_folder`, `ts_name`, `ts_timeZone`, `ts_Y2010`, `ts_Y2011`, `ts_W01`, `ts_W02`,
		`ts_W03`, `ts_W04`, `ts_W05`, `ts_W06`, `ts_W07`, `ts_SP1`, `ts_SP2`, `ts_SP3`, `ts_folderA`, `ts_folderB`, `ts_folderC`,
		`ts_folderD`, `ts_folderE`, `ts_folderF`, `ts_folderG`, `ts_folderH`) values (clientId, inFolder, tsName, timeZone, repeat('0',365),
		repeat('0',365), repeat('B',48), repeat('B',48), repeat('B',48), repeat('B',48), repeat('B',48), repeat('B',48), repeat('B',48),
		repeat('B',48), repeat('B',48), repeat('B',48), 'not used', 'not used', 'not used', 'not used', 'not used', 'not used', 'not used', 'not used');
	END IF;
	SELECT count(*) INTO kount FROM timeSwitch
		    WHERE ts_clientId= clientId AND ts_folder = inFolder ;
	IF kount =1 THEN
		RETURN 'ok';
	ELSE
		RETURN 'failed';
	END IF;
END;

