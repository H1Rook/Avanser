create
    definer = proc@`%` function fn_getBillCallType2(param_target char(55), param_ani char(55), param_bnum char(55)) returns varchar(10)
    deterministic
BEGIN
	DECLARE callFrom  char(2);
	DECLARE callTo  char(2);
	DECLARE countryFrom  char(5);
	DECLARE countryTo  char(5);
	DECLARE callType char(5);
	DECLARE mobilePrefix char(5);
	
	SET countryFrom = (SELECT REPLACE(SUBSTRING_INDEX(param_callFrom,'-',1),'+',''));
	SET countryTo = (SELECT REPLACE(SUBSTRING_INDEX(param_callTo,'-',1),'+',''));
	
	IF (countryFrom!=countryTo) THEN
		RETURN 'II';
	END IF;
	
	
	IF (countryFrom='61') THEN
		SET mobilePrefix = '04';
	ELSEIF (countryFrom='64') THEN
		SET mobilePrefix = '02';
	ELSEIF (countryFrom='60') THEN
		SET mobilePrefix = '01';
	ELSE
		SET mobilePrefix = 'XX';
	END IF;
	
	SET callFrom = (SELECT SUBSTRING_INDEX(param_callFrom,'-',-1));
	SET callTo = (SELECT SUBSTRING_INDEX(param_callTo,'-',-1));
	
	
	SET callFrom =	 (SELECT (Replace(param_callFrom,'61',0),2));
	IF(callTo='04') THEN
		IF(callFrom!='04') THEN
			SET callType = 'MT';
		ELSE
			SET callType = 'MM';
		END IF;
	ELSE
		IF(callFrom!='04' ) THEN
			IF(UCASE(callFrom)='PR' or UCASE(callFrom)='AN' )THEN
				SET callType = 'L';
			ELSE
				IF(callTo!=callFrom)THEN
					SET callType = 'N';
				ELSE
					SET callType = 'L';
				END IF;
			END IF;
		ELSE
			SET callType = 'M';
		END IF;
	END IF;
	RETURN callType;
END;

