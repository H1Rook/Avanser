create
    definer = proc@`%` procedure sp_monthly_by_folder(IN folder varchar(20), IN YYYYMM int(6))
SELECT
  DATE_FORMAT(`cd_localTime`,'%d %b %Y %H:%i') as 'Start Time'
  ,CASE `cd_ani`
	WHEN '' then concat('Private-Ref:',`cd_cutamper`)
	WHEN 'Private' then concat('Private-Ref:',`cd_cutamper`)
        ELSE fn_cleanNum(`cd_ani`,'','') END as 'Calling Number'
  ,`cd_location` as 'Location'
  ,`cd_adName` as 'Ad Source Name'
  ,fn_cleanNum(`cd_bnum`,'','') as 'Dialed Number'
  ,CASE	`cd_callStatus`
        WHEN 1 then 'Answered'
        WHEN 2 then 'Busy'
        ELSE 'Missed' END as 'Status'
  ,SEC_TO_TIME(`cd_callDuration`) as 'Duration'
  From `cdr` where `cd_folder`=folder and extract(YEAR_MONTH from `cd_startTime`)=YYYYMM
order by `cd_localTime`;

