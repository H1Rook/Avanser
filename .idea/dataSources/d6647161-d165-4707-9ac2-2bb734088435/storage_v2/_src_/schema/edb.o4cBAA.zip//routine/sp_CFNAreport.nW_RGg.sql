create
    definer = proc@`%` procedure sp_CFNAreport()
BEGIN

DROP TABLE IF EXISTS `tmp_CFNA`;
CREATE TABLE `tmp_CFNA` (
  `Client_ID` int(10) NOT NULL default '0',
  `BNUM` varchar(40) NOT NULL,
  `DNIS` varchar(40) NOT NULL,
  `Provisioned` date default NULL,
  `Decommissioned` date default NULL,
  `CFNA` varchar(20) NOT NULL,
  `Action` varchar(5) NOT NULL,
  `Target` varchar(100) NOT NULL,
  `Instructions` char(200) character set utf8 NOT NULL default ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
INSERT INTO `tmp_CFNA`
(SELECT `Client_ID`, `Number` as 'BNUM', `dp_dnis` as `DNIS`, `Provisioned`, `Decommissioned`, `CFNA`, `mn_action` as 'Action', `mn_target` as 'Target', '' as 'Instructions'
FROM `inbound`, `menu`,`dispatcher`
WHERE `dp_bnum` = `Number`
AND `dp_clientId` = `Client_ID`
AND `dp_folder` = `mn_folder`
AND `Provider` like 'U%'
AND `mn_action` = 'xfr'
AND `mn_item` ='-1'
AND `mn_parent`='0');

DROP TABLE if EXISTS `mem_defaults`;
CREATE TABLE `mem_defaults` ENGINE=MEMORY
SELECT DISTINCT `mn_default` as 'md_default'
FROM `menu`
WHERE `mn_action` not in ('xfr','v','o','s','f')
AND `mn_item` ='-1'
AND `mn_parent`='0';

DROP TABLE if EXISTS `mem_NOXfolder`;
CREATE TABLE `mem_NOXfolder` ENGINE=MEMORY
SELECT `mn_folder` as 'nox_folder', `mn_clientId` as 'nox_clientId', `mn_target` as 'nox_target'
FROM `menu`
WHERE `mn_folder` IN (SELECT `md_default` from `mem_defaults`)
AND `mn_action`='xfr'
AND `mn_parent`='0'
AND `mn_item`='-1'
ORDER BY `mn_folder`;

INSERT INTO `tmp_CFNA`
(SELECT `Client_ID` , `Number` as 'BNUM', `dp_dnis` as `DNIS`, `Provisioned`, `Decommissioned`, `CFNA`, `mn_action` as 'Action', `nox_target` as 'Target', '' as 'Instructions'
FROM `inbound`, `dispatcher`, `menu`
LEFT JOIN `mem_NOXfolder` ON `mn_clientId`=`nox_clientId` AND `mn_default`=`nox_folder`
WHERE `dispatcher`.`dp_bnum` = `inbound`.`Number`
AND `dp_clientId` = `Client_ID`
AND `dp_folder` = `mn_folder`
AND `inbound`.`Provider` like  'U%'
AND `menu`.`mn_action` <> 'xfr'
AND `menu`.`mn_item` ='-1'
AND `menu`.`mn_parent`='0');

UPDATE tmp_CFNA set `Instructions` = 'OK' where isnull(Decommissioned) and `CFNA`=`Target`;
UPDATE tmp_CFNA set `Instructions` = 'OK' where not isnull(Decommissioned) and `CFNA`='' and `Instructions`='';
UPDATE tmp_CFNA set `Instructions` = 'Remove CFNA!' where not isnull(Decommissioned) and `CFNA`!='' and `Instructions`='';
UPDATE tmp_CFNA set `Instructions` = Concat('Change CFNA to ',`Target`) where isnull(Decommissioned) and `CFNA`!=`Target` and `Target`!='' and `Instructions`='';
UPDATE tmp_CFNA set `Instructions` = 'Manual Check needed' where `Instructions`='';
UPDATE tmp_CFNA set `Instructions` = 'Ignore' where LEFT(`BNUM`,5)!='+61-1';

DROP TABLE if EXISTS `mem_defaults`;
DROP TABLE if EXISTS `mem_NOXfolder`;
END;

