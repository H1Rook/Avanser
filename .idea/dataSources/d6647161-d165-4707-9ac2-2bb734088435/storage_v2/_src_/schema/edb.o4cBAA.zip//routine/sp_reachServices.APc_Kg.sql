create
    definer = proc@`%` procedure sp_reachServices()
SELECT provisioned as 'Start Date', as_adName as 'Service Name', dp_bnum as Inbound,
case mn_action when 'e' then 'EBR' when 'l' then 'LBR' when 'o' then 'Offline' when 'r' then 'PCP' when 's' then 'IVR' else 'Other' end as routing
FROM menu
JOIN dispatcher ON dp_folder = mn_folder
JOIN adSource on as_bnum=dp_bnum
JOIN inbound on number=dp_bnum
where
mn_parent =0
AND mn_item = -1
AND mn_clientId=6094
AND mn_action <> 'x'
AND (isnull(decommissioned) or (year(decommissioned)*100+month(decommissioned) = year(curdate())*100+month(curdate())))
order by routing, provisioned;

