create
    definer = proc@`%` function fn_deleteFolder(clientId int(8), mnFolder varchar(20), mnId int(10),
                                                sessionUser varchar(50)) returns varchar(20) deterministic
BEGIN
DECLARE duplicatemenucount INT(5);
DECLARE duplicatedispcount INT(5);
	
	SET duplicatemenucount =(SELECT count(*) from menu WHERE mn_clientId=clientId AND mn_forward = mnFolder OR mn_default = mnFolder OR mn_auxFolder = mnFolder);
	SET duplicatedispcount =(SELECT count(*) from dispatcher WHERE dp_clientId=clientId AND dp_folder = mnFolder);
	IF (duplicatemenucount>0 OR duplicatedispcount>0) THEN
		RETURN 'failed';
	ELSE
		DELETE FROM menu WHERE mn_id=mnId AND mn_clientId=clientId;
		
		INSERT INTO ws_auditTrail (at_dateTime, at_source, at_who, at_what, at_result, at_detail ) Values (now(), 3, sessionUser, clientId, 'Folder Deleted', mnFolder);
		RETURN 'success';
	END IF;
END;

