create
    definer = proc@`%` procedure sp_user2(IN actionx char(255), IN mn_id_param char(255), IN mn_dtmfName char(255),
                                          IN mn_target char(255), IN mn_clid char(255), IN mn_emailTo char(255),
                                          IN mn_emailCc char(255), IN mn_emailBcc char(255), IN mn_record char(255),
                                          IN mn_notifyAll char(255), IN mn_fax char(255), IN mn_timeZone char(255),
                                          IN mn_clientId_param char(255), IN mn_subject char(255),
                                          IN mn_action char(255), IN mn_item char(255), IN mn_noWait char(255),
                                          IN mn_template char(255), IN whisper char(255), IN greeting char(255),
                                          IN mn_route char(255), IN mn_customVox char(255), IN mn_auxFolder char(255),
                                          IN mn_default char(255))
BEGIN
DECLARE confFolder  char(255);
DECLARE confParent char(255);
DECLARE confItem char(255);
DECLARE confWhisper 	char(255);
DECLARE confGreeting	char(255);
DECLARE mn_auxFolder_param varchar(11);
SET mn_auxFolder_param = '';
IF actionx  = 1 THEN
	IF mn_action='x' THEN
		set confParent='0';
		set confItem= '-1';
	ELSE
		set confParent='0';
		set confItem=mn_item;
	END IF;
	IF mn_id_param  = 0  THEN
		IF (mn_clientId_param = 6094) THEN
			
			SET confFolder = (SELECT max(mn_folder)+1 FROM menu WHERE mn_clientId=mn_clientId_param and mn_folder BETWEEN 60940000  AND 60950000 );
		ELSE
			
			SET confFolder = (SELECT max(mn_folder)+1 FROM menu WHERE mn_clientId=mn_clientId_param and mn_folder BETWEEN 60000000  AND 70000000 );
		END IF;
		IF isNULL(confFolder) THEN
            		SET confFolder = (SELECT concat(mn_clientId_param,'0001'));
        	END IF;
		IF mn_action = 't' THEN
			SELECT fn_createTS(mn_clientId_param, confFolder, mn_dtmfName, mn_timeZone);
			SET mn_auxFolder_param = confFolder;
		END IF;
		SET confGreeting = 'not_available.wav';
		SET confWhisper = '';
		INSERT INTO menu ( mn_dtmfName, mn_target, mn_clid,  mn_emailTo,
				mn_emailCc, mn_emailBcc,
				mn_record, mn_notifyAll, mn_fax, 	mn_timeZone,
				mn_subject, mn_action, mn_item, 	mn_noWait,
				mn_template,	mn_whisper, mn_greeting, mn_clientId,
				mn_parent, mn_folder, mn_customVox, mn_route, mn_auxFolder, mn_default)
		VALUES (	mn_dtmfName, mn_target, mn_clid, mn_emailTo,
				mn_emailCc, mn_emailBcc,
				mn_record, mn_notifyAll, mn_fax, 	mn_timeZone,
				mn_subject, mn_action, confItem, mn_noWait,
				mn_template,	confWhisper, confGreeting, mn_clientId_param,
				confParent, confFolder, mn_customVox, mn_route, mn_auxFolder, mn_default);
	ELSE
		UPDATE menu
			SET 	mn_dtmfName	= mn_dtmfName,
				mn_target 	= mn_target,
				mn_clid		= mn_clid,
				mn_emailTo	= mn_emailTo,
				mn_emailCc	= mn_emailCc,
				mn_emailBcc	= mn_emailBcc,
				mn_record	= mn_record,
				mn_notifyAll	= mn_notifyAll,
				mn_fax		= mn_fax,
				mn_timeZone	= mn_timeZone,
				mn_subject	= mn_subject,
				mn_action	= mn_action,
				mn_item		= mn_item,
				mn_noWait	= mn_noWait,
				mn_template	= mn_template,
				mn_route		= mn_route,
				mn_customVox= mn_customVox,
				mn_auxFolder	= mn_auxFolder,
				mn_default = mn_default
		WHERE mn_id=mn_id_param AND mn_clientId=mn_clientId_param ;
	END IF;
END IF;
IF actionx  = 2 THEN
	DELETE FROM menu WHERE mn_id=mn_id_param AND mn_clientId=mn_clientId_param  ;
END IF;
IF actionx  = 3 THEN
	SET confFolder = (SELECT max(mn_folder)+1 FROM menu WHERE mn_clientId=mn_clientId_param and mn_folder BETWEEN 60000000  AND 70000000 );
	IF isNULL(confFolder) THEN
           		SET confFolder = (SELECT concat(mn_clientId_param,'0001'));
        END IF;
	INSERT INTO menu ( mn_dtmfName, mn_agentId,mn_target, mn_clid,  mn_emailTo,
				mn_emailCc, mn_emailBcc,
				mn_record, mn_notifyAll, mn_fax, 	mn_timeZone,
				mn_subject, mn_action, mn_item, 	mn_noWait,
				mn_template,	mn_whisper, mn_greeting, mn_clientId,
				mn_parent, mn_folder, mn_customVox, mn_route, mn_auxFolder, mn_default)
		(Select  mn_dtmfName, mn_agentId,mn_target, mn_clid,  mn_emailTo,
				mn_emailCc, mn_emailBcc,
				mn_record, mn_notifyAll, mn_fax, 	mn_timeZone,
				mn_subject, mn_action, mn_item, 	mn_noWait,
				mn_template,	mn_whisper, mn_greeting, mn_clientId,
				mn_parent, confFolder, mn_customVox, mn_route, mn_auxFolder, mn_default from menu where mn_id = mn_id_param ) ;
END IF;
END;

