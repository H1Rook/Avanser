create
    definer = proc@`%` function fn_duplicateDNIS(param_clientId int(8), param_dnisterm varchar(20)) returns varchar(20)
    deterministic
BEGIN
DECLARE countddispdnis INT(5);
DECLARE countdibdnis INT(5);
IF param_clientId <>'' THEN
	
	SET countddispdnis = (SELECT count(*) FROM dispatcher WHERE dp_dnis = param_dnisterm);
	IF (countddispdnis > 0) THEN
		RETURN 'faileddispatcher';
	ELSE
		
		SET countdibdnis = (SELECT count(*) FROM inbound WHERE Terminating_No = param_dnisterm AND Decommissioned IS NULL);
		IF (countdibdnis > 0) THEN
			RETURN 'failedinbound';
		ELSE
			RETURN 'success';
		END IF;
	END IF;
END IF;
END;

