create
    definer = proc@`%` procedure sp_broadcast(IN sendDate date, IN sendTo varchar(50))
BEGIN
insert into msgQ(`mq_dateTime`,`mq_host`,`mq_clientId`,`mq_emailFrom`,`mq_emailTo`,`mq_template`,`mq_subject`,`mq_status`)
values (sendDate,'edb',6000,'callmanager@avanser.com.au',sendTo,'holidays.html','AVANSER Support for the Christmas period 2010',0);
END;

