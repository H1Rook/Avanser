create
    definer = proc@`%` function fn_createBulkService(client_id int(8), sessionUser varchar(50),
                                                     folderNumber varchar(20), InbNumber varchar(20),
                                                     AdSource varchar(50), pvDate date, param_proxytag varchar(40),
                                                     param_mn_target varchar(100), param_mn_record int(2),
                                                     param_subject varchar(100), param_emailFrom varchar(100),
                                                     param_emailTo varchar(255), param_emailCc varchar(255),
                                                     param_emailBcc varchar(255), param_mn_timeout int(4),
                                                     param_timezone int(4), param_mntemplate varchar(50),
                                                     param_notifyall int(2)) returns varchar(20) deterministic
BEGIN
DECLARE confHost  VARCHAR(10);
DECLARE confdp_dnis VARCHAR(50);
DECLARE count_adsource Integer(5);
DECLARE checkdnis VARCHAR(50);
DECLARE confFolder VARCHAR(20);
DECLARE checkfolder VARCHAR(20);
DECLARE checkadsource VARCHAR(20);
DECLARE templateId INT(10);

	
	SET checkadsource = (SELECT COUNT(*) FROM adSource WHERE as_clientId=client_id AND as_adName=AdSource);
	IF (checkadsource>0) THEN
		RETURN 'failedadsource';
	ELSE
		
		SET confHost 	= (SELECT AVANSER_ref FROM inbound WHERE  Number = InbNumber);
		SET confdp_dnis = (SELECT Terminating_No FROM inbound WHERE  Number = InbNumber);
		SET checkdnis = (SELECT COUNT(*) FROM dispatcher WHERE dp_dnis=confdp_dnis);
		IF(checkdnis>0) THEN
			RETURN 'failed2';
		ELSE
			
			SET checkfolder = (SELECT COUNT(*) FROM menu WHERE mn_clientId=client_id AND mn_folder=folderNumber);
			IF checkfolder=0 THEN
				IF param_mntemplate!='' THEN
					SET templateId = (SELECT mn_id FROM menu WHERE mn_folder='default' AND mn_dtmfname=param_mntemplate);
					IF templateId>0 THEN
						
						INSERT INTO menu(mn_clientId, mn_folder, mn_agentId, mn_parent, mn_item, mn_dtmfName, mn_action, mn_noWait, mn_route, mn_default, mn_target, mn_forward, mn_clid, mn_customVox,
							mn_greeting, mn_subject, mn_emailFrom, mn_emailTo, mn_emailCc, mn_emailBcc, mn_template, mq_mobile, mn_sms, mn_whisper, mn_ack, mn_prompt, mn_submenu, mn_notifyAll,
							mn_record, mn_timeOut, mn_timeZone, mn_ap, mn_fax, mn_auxFolder, mn_url, mn_filter, mn_ignore, fws)
						SELECT client_id, folderNumber, 0, 0, -1, AdSource, 'xfr', 1, mn_route, mn_default, param_mn_target, mn_forward, mn_clid, mn_customVox,
							mn_greeting, IF(param_subject!='',param_subject,mn_subject), IF(param_emailFrom!='',param_emailFrom,mn_emailFrom),
							IF(param_emailTo!='',param_emailTo,mn_emailTo),  IF(param_emailCc!='',param_emailCc,mn_emailCc), IF(param_emailBcc!='',param_emailBcc,mn_emailBcc),
							mn_template, mq_mobile, mn_sms, mn_whisper,mn_ack, mn_prompt, mn_submenu,  IF(param_notifyall!=0,param_notifyall,mn_notifyAll),
							 IF(param_mn_record!=0,param_mn_record,mn_record), IF(param_mn_timeout!=0,param_mn_timeout,mn_timeOut),
							 IF(param_timezone!='',param_timezone,mn_timeZone), mn_ap, mn_fax, mn_auxFolder, mn_url, mn_filter, mn_ignore, fws
						FROM menu
						WHERE mn_id= templateId;
					ELSE
						RETURN 'notemplate';
					END IF;
				ElSE
					RETURN 'notemplate';
				END IF;
			END IF;
			
			INSERT INTO dispatcher (dp_clientId, dp_bnum, dp_dnis, dp_country, dp_host, dp_script, dp_folder, dp_comments)
			   	VALUES (client_id, InbNumber, confdp_dnis, 'AU', confHost, 'autoattendant', folderNumber, AdSource);
			
			UPDATE inbound SET Client_ID = client_id,
				  Terminating_Service = AdSource,
				  Provisioned	= pvDate,
				   in_country = 'AU',
				  Decommissioned = NULL
			WHERE Number = InbNumber;
			
			INSERT INTO adSource (as_clientId , as_adName, as_bnum, as_cost, as_campaignStart, as_proxy)
			   	VALUES (client_id, AdSource, InbNumber , 1, pvDate, param_proxytag);
			
			INSERT INTO portal_clientbnum (cb_clientId, cb_bnum, cb_clientIdx, cb_accessflag)
			   	VALUES (client_id, InbNumber, client_id, '9999');
			
			INSERT INTO ws_auditTrail (at_dateTime, at_source, at_who, at_what, at_result, at_detail ) Values (now(), 3, sessionUser, client_id, 'New Service', InbNumber);

			RETURN 'success';
		END IF;
	END IF;
END;

