create
    definer = proc@`%` procedure sp_pvrl2(IN param_action char(255), IN param_as_id char(255),
                                          IN param_as_adName char(255), IN param_destination char(255),
                                          IN param_published char(255), IN param_timeout char(255),
                                          IN param_as_rlwocID char(255), IN param_as_masterID char(255),
                                          IN param_as_proxy char(255), IN param_timeZone char(255),
                                          IN param_record char(255), IN confHost char(255), IN confScript char(255),
                                          IN confClient char(255), IN confClientID char(255), IN confUser char(255),
                                          IN as_notesParam char(255), IN country char(20))
BEGiN
DECLARE confFolder  char(255);
DECLARE confTerminatingNo  char(255);
DECLARE stbnum char(255);
DECLARE last1 INT;
DECLARE last2 INT;
DECLARE last3 INT;
DECLARE last4 INT;
DECLARE menuaction char(20);
DECLARE rlcount INT;
    IF param_action='1' THEN
        SET stbnum = (SELECT fn_cleanNum(as_bnum,'','') FROM adSource WHERE as_id=param_as_id LIMIT 1);
        SET confTerminatingNo = ( SELECT Terminating_No FROM inbound WHERE fn_cleanNum(Number,'','')=stbnum AND  client_ID=confClientID LIMIT 1);
        UPDATE adSource SET  as_adName=param_as_adName, as_rlwpcID=param_as_rlwocID, as_masterID=param_as_masterID, as_proxy=param_as_proxy, as_notes=as_notesParam
        WHERE as_clientId=confClientID AND as_id=param_as_id;
	SET menuaction = (SELECT  mn_action FROM menu  WHERE mn_clientId=confClientID AND mn_folder=(SELECT dp_folder from dispatcher where fn_cleanNum(dp_bnum,'','')=stbnum LIMIT 1) LIMIT 1);
	IF menuaction ='x' OR menuaction ='xfr' THEN
	        UPDATE menu  SET mn_dtmfName=param_as_adName, mn_target=param_destination, mn_record=param_record, mn_timeOut=param_timeout, mn_timeZone= fn_getTimeCode(param_destination,country)
	        WHERE mn_clientId=confClientID AND mn_folder=(SELECT dp_folder from dispatcher where fn_cleanNum(dp_bnum,'','')=stbnum );
	END If;
	SET rlcount = (SELECT count(*) FROM RLadSource WHERE fn_cleanNum(rlas_bnum,'','')= fn_cleanNum(param_published,'',''));
	IF(rlcount>0) THEN
		UPDATE RLadSource SET rlas_adName=param_as_adName, rlas_clientId=confClientID, rlas_wpcID=param_as_rlwocID, rlas_masterID=param_as_masterID, rlas_proxy=param_as_proxy,  rlas_bnum=param_published WHERE fn_cleanNum(rlas_bnum,'','')=fn_cleanNum(param_published,'','');
	ELSE
		INSERT INTO RLadSource (rlas_clientId, rlas_adName, rlas_bnum, rlas_wpcID, rlas_masterID, rlas_proxy) VALUES (confClientID, param_as_adName, param_published,   param_as_rlwocID,  param_as_masterID,  param_as_proxy) ;
	END IF;
	INSERT INTO ws_auditTrail ( at_dateTime, at_source, at_who, at_what, at_result, at_detail ) Values ( now(), 1, confUser, confClientID, 'Update' , CONCAT('adSourceId=', param_as_id,' - Destination=',param_destination ) );
    END IF;
	
    IF param_action='2' THEN
	SET confFolder = (SELECT max(mn_folder + 1) AS next FROM menu WHERE mn_clientId=confClientID AND mn_folder BETWEEN 60940000 AND 60949999);
        IF isNULL(confFolder) THEN
            SET confFolder = (SELECT concat(confClientID,'0001'));
        END IF;
        UPDATE inbound SET client_ID=confClientID, client=confClient,Terminating_Service=confClient, Requested=now(), Provisioned=now(), Decommissioned=NULL, Bill_Source='CDR', cfna=''  WHERE fn_cleanNum(Number,'','')=fn_cleanNum(param_published,'','');
        	SET confTerminatingNo = ( SELECT Terminating_No FROM inbound WHERE fn_cleanNum(Number,'','')=fn_cleanNum(param_published,'','') AND  client_ID=confClientID );
        INSERT INTO adSource ( as_clientId, as_adName, as_bnum, as_campaignStart, as_rlwpcID, as_masterID, as_proxy, as_notes)   VALUES (confClientID, param_as_adName, param_published, now(), param_as_rlwocID, param_as_masterID, param_as_proxy, as_notesParam  );
	set last1= LAST_INSERT_ID();
        INSERT INTO dispatcher ( dp_bnum, dp_dnis, dp_host, dp_script, dp_clientId, dp_folder, dp_country )  VALUES (param_published, confTerminatingNo, confHost, confScript, confClientID, confFolder, country);
	set last2= LAST_INSERT_ID();
	IF (isNULL(param_timeout) or LENGTH(TRIM(param_timeout))=0) THEN
            SET param_timeout = 0;
        END IF;
        IF (isNULL(param_record) or LENGTH(TRIM(param_record))=0) THEN
            SET param_record = 0;
        END IF;
        INSERT INTO menu ( mn_clientId, mn_folder, mn_agentId, mn_parent, mn_item, mn_dtmfName, mn_action, mn_noWait, mn_target, mn_greeting, mn_record, mn_timeOut, mn_timeZone)
			VALUES  (confClientID, confFolder, confFolder,0,-1, param_as_adName,'x',1, param_destination, 'longbusy.wav', param_record, param_timeout , fn_getTimeCode(param_destination,country) );
	set last3= LAST_INSERT_ID();
        INSERT INTO portal_clientbnum (cb_clientId, cb_bnum, cb_clientIdx, cb_accessflag) VALUES  (confClientID, param_published, confClientID, '9999');
	set last4= LAST_INSERT_ID();
	SET rlcount = (SELECT count(*)  FROM RLadSource WHERE fn_cleanNum(rlas_bnum,'','')=fn_cleanNum(param_published,'','') ); 
	IF(rlcount>0) THEN
		UPDATE RLadSource SET rlas_adName=param_as_adName, rlas_clientId=confClientID, rlas_wpcID=param_as_rlwocID, rlas_masterID=param_as_masterID, rlas_proxy=param_as_proxy,  rlas_bnum=param_published WHERE fn_cleanNum(rlas_bnum,'','')=fn_cleanNum(param_published,'','');
	ELSE
		INSERT INTO RLadSource (rlas_clientId, rlas_adName, rlas_bnum, rlas_wpcID, rlas_masterID, rlas_proxy) VALUES (confClientID, param_as_adName, param_published,   param_as_rlwocID,  param_as_masterID,  param_as_proxy) ;
	END IF;
	INSERT INTO ws_auditTrail (at_dateTime, at_source, at_who, at_what, at_result, at_detail) Values (now(), 1, confUser, confClientID, 'Insert', CONCAT('adSourceId=', last1, ' - dispatcher=', last2, ' - Menu=', last3, ' - Portal_clientbnum=',last4,' - Destination=',param_destination));
    END IF;
    IF param_action='3' THEN
        SET stbnum = (SELECT fn_cleanNum(as_bnum,'','') as as_bnum FROM adSource WHERE as_id=param_as_id );
        SET confFolder = (SELECT dp_folder FROM dispatcher WHERE  dp_clientId=confClientID and  fn_cleanNum(dp_bnum,'','')=stbnum);
        DELETE FROM portal_clientbnum where cb_clientid=confClientID AND fn_cleanNum(cb_bnum,'','')=stbnum;
        DELETE FROM dispatcher where dp_clientId=confClientID AND fn_cleanNum(dp_bnum,'','')=stbnum;
        DELETE FROM adSource where as_clientId=confClientID AND fn_cleanNum(as_bnum,'','')=stbnum;
        DELETE FROM menu  where mn_clientId=confClientID AND mn_folder=confFolder;
        UPDATE inbound set decommissioned=now() where client_ID=confClientID and fn_cleanNum(Number,'','')=stbnum;
	INSERT INTO ws_auditTrail (at_dateTime, at_source, at_who, at_what, at_result, at_detail) Values (now(), 1, confUser, confClientID, 'Deleted', CONCAT('adSourceId=', param_as_id, ' - dispatcher Folder=', confFolder, ' - inbound number=', stbnum));
    END IF;
END;

