create
    definer = proc@`%` function fn_getCallType(param_cd_id varchar(50)) returns varchar(20) deterministic
BEGIN
	DECLARE callFrom  char(255);
	DECLARE callTo  char(255);
	DECLARE country char(2);
	
	DECLARE prefix char(3);
	DECLARE mobile char(3);
	
	DECLARE callType char(5);
	
	SET country = (SELECT `cd_country` FROM `cdr` WHERE `cd_id`=param_cd_id LIMIT 1);
	
	SET prefix='null';
	SET mobile = 'err';
	IF (country='AU') THEN
		SET prefix = '61';
		SET mobile = '04';
	END IF;
	IF (country='NZ') THEN
		SET prefix = '64';
		SET mobile = '02';
	END IF;
	IF (country='MY') THEN
		SET prefix = '60';
		SET mobile = '01';
	END IF;
	SET callTo = (SELECT `cd_outNum` FROM `cdr` WHERE `cd_id`=param_cd_id LIMIT 1);
	SET callFrom = (SELECT `cd_ani` FROM `cdr` WHERE `cd_id`=param_cd_id LIMIT 1);
	IF ( callFrom REGEXP ('^\\+[0-9]{1,3}\\-[0-9]{6,12}$') ) THEN
		SET callFrom = SUBSTRING_INDEX(SUBSTRING(callFrom,2), '-', -1);
	ELSEIF ( LEFT(callFrom,2)=prefix ) THEN
		SET callFrom = CONCAT('0',SUBSTRING(callFrom,2));
	END IF;
	IF ( callTo REGEXP ('^\\+[0-9]{1,3}\\-[0-9]{6,12}$') ) THEN
		SET callTo = SUBSTRING_INDEX(SUBSTRING(callTo,2), '-', -1);
	ELSEIF ( LEFT(callTo,2)=prefix ) THEN
		SET callTo = CONCAT('0',SUBSTRING(callTo,2));
	END IF;
	SET callTo = LEFT(callTo,2);
	SET callFrom = LEFT(callFrom,2);
	IF(callTo=mobile) THEN
		IF(callFrom!=mobile) THEN
			SET callType = 'MT';
		ELSE
			SET callType = 'MM';
		END IF;
	ELSE
		IF(callFrom!=mobile ) THEN
			IF(UCASE(callFrom)='PR' or UCASE(callFrom)='AN' )THEN
				SET callType = 'L';
			ELSE
				IF(callTo!=callFrom)THEN
					SET callType = 'N';
				ELSE
					SET callType = 'L';
				END IF;
			END IF;
		ELSE
			SET callType = 'M';
		END IF;
	END IF;
	
	IF (mobile='err') THEN
		SET callType = 'ER';
	END IF;
	
	UPDATE cdr  SET cd_billCallType=callType WHERE cd_id=param_cd_id;
	
	RETURN callType;
END;

