create
    definer = proc@`%` function fn_getLOCN(telNumber varchar(50)) returns varchar(20) deterministic
BEGIN
	DECLARE x  INT;
	DECLARE MCHLGD VARCHAR(255);
        SET x = 12;
	IF (SUBSTRING(telNumber,1,2) != '61') THEN
		SET telNumber = CONCAT('61',SUBSTRING(telnumber,1,50));
	END IF;
	WHILE x  >= 3 DO
		SET MCHLGD =(SELECT cli_id FROM ebr_cli WHERE cli_prefix =SUBSTRING(telNumber,1,x) limit 1);
		 IF  ( MCHLGD != null OR MCHLGD!='') THEN
			SET  x = 0;
			RETURN  (MCHLGD);
		ELSE
			SET  x = x - 1;
		END IF;
	END WHILE;
	RETURN 0;
END;

