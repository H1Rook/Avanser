create
    definer = proc@`%` function fn_createService(client_id int, UserId varchar(100), AdSource varchar(50),
                                                 InbNumber varchar(20), Folder varchar(20), Target varchar(100),
                                                 script varchar(50), inboundId int, pvDate date, wpcId int,
                                                 masterId int) returns varchar(20) deterministic
BEGIN
DECLARE confHost  VARCHAR(10);
DECLARE confdp_dnis VARCHAR(50);
DECLARE count_adsource Integer(5);
DECLARE checkdnis VARCHAR(50);
DECLARE conf_country VARCHAR(2);
	SET count_adsource = (SELECT COUNT(*) FROM adSource WHERE as_clientId=client_id AND as_adName=AdSource);
	IF (count_adsource> 0) THEN
		RETURN 'failed1';
	ELSE
		SET confHost 		= ( SELECT AVANSER_ref FROM inbound WHERE  ID = inboundId );
		SET confdp_dnis 	= ( SELECT Terminating_No FROM inbound WHERE  ID = inboundId );
		SET checkdnis = (SELECT COUNT(*) FROM dispatcher WHERE dp_dnis=confdp_dnis);
		SET conf_country = ( SELECT in_country FROM inbound WHERE  ID = inboundId );
		IF(checkdnis>0) THEN
			RETURN 'failed2';
		ELSE
			INSERT INTO dispatcher (dp_clientId, dp_bnum, dp_dnis, dp_country, dp_host, dp_script, dp_folder, dp_comments)
				   VALUES (client_id, InbNumber, confdp_dnis, conf_country,confHost, script, Folder, AdSource);
			UPDATE inbound SET Client_ID	= client_id,
					  Terminating_Service = AdSource,
					  Requested	= NOW(),
					  Provisioned	= pvDate,
					  Decommissioned = null
			WHERE	ID = inboundId;
			INSERT INTO adSource (as_clientId , as_adName, as_bnum, as_cost, as_campaignStart,as_rlwpcID,as_masterID)
				   VALUES (client_id, AdSource, InbNumber , 1, pvDate, wpcId, masterId);
			INSERT INTO portal_clientbnum (cb_clientId, cb_bnum, cb_clientIdx, cb_accessflag)
				   VALUES (client_id, InbNumber, client_id, '9999');
			INSERT INTO ws_auditTrail (at_dateTime, at_source, at_who, at_what, at_result, at_detail ) Values (now(), 3, UserId, client_id, 'New Service', InbNumber);
			RETURN InbNumber;
		END IF;
	END IF;
END;

