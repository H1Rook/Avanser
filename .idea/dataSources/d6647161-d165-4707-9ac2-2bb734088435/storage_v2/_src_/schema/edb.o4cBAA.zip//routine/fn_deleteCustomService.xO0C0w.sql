create
    definer = proc@`%` function fn_deleteCustomService(param_clientId int, param_as_id int, sessionUser varchar(50)) returns varchar(50)
    deterministic
BEGIN
DECLARE confFolder  char(255);
DECLARE stbnum char(255);

IF param_clientId <>'' THEN

	SET stbnum = (SELECT fn_cleanNum(as_bnum,'','') as as_bnum FROM adSource WHERE as_id=param_as_id);
        SET confFolder = (SELECT dp_folder FROM dispatcher WHERE  dp_clientId=param_clientId and  fn_cleanNum(dp_bnum,'','')=stbnum);

	
        DELETE FROM portal_clientbnum where cb_clientid=param_clientId AND fn_cleanNum(cb_bnum,'','')=stbnum;
	
        DELETE FROM dispatcher where dp_clientId=param_clientId AND fn_cleanNum(dp_bnum,'','')=stbnum;
	
        DELETE FROM adSource where as_clientId=param_clientId AND fn_cleanNum(as_bnum,'','')=stbnum;
	
        DELETE FROM menu  where mn_clientId=param_clientId AND mn_folder=confFolder;
	
        UPDATE inbound set decommissioned=now() where client_ID=param_clientId and fn_cleanNum(Number,'','')=stbnum;
	
	INSERT INTO ws_auditTrail (at_dateTime, at_source, at_who, at_what, at_result, at_detail) Values (now(), 1, sessionUser, param_clientId, 'Deleted', CONCAT('adSourceId=', param_as_id, ' - dispatcher Folder=', confFolder, ' - inbound number=', stbnum));

	RETURN  'success';
END IF;
END;

