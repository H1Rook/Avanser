create
    definer = webApp@`%` procedure sp_decommissionClientNumber(IN param_mode char(255), IN param_number char(255),
                                                               IN param_clientId char(255),
                                                               IN param_ibclientId char(255))
BEGIN
IF param_number  != '' THEN
	IF param_clientId  != '' THEN
	IF param_mode ='archive'  THEN
		
		
		INSERT INTO ib_archive ( `Type`, Region, Number, Provider, Client_ID, Client, Terminating_No, Terminating_Service, Requested,
						Provisioned, Decommissioned, AVANSER_ref,  Client_ref, Carrier_ref, Cost_rate, Charge_rate, Bill_source, CFNA,
						calls, Notes, `Status`, Client_Notes)
		(Select  `Type`, Region, Number, Provider, Client_ID, Client, Terminating_No, Terminating_Service, Requested,
						Provisioned, Decommissioned, AVANSER_ref,  Client_ref, Carrier_ref, Cost_rate, Charge_rate, Bill_source, CFNA,
						calls, Notes, `Status`, Client_Notes  from inbound  where Number = param_number AND Client_ID= param_clientId ) ;
		
		INSERT INTO cdr_archive (cd_startTime, cd_localTime, cd_outStartTime, cd_endTime, cd_callDuration, cd_outDuration, cd_ani, cd_state, cd_location,
			cd_dnis, cd_bnum, cd_clientId, cd_script, cd_outNum, cd_branch, cd_inChannel, cd_outChannel, cd_message, cd_recording, cd_dtmf,
			cd_dtmfName, cd_callStatus, cd_ap, cd_host, cd_folder, cd_cp01, cd_cp02, cd_cp03, cd_cp04, cd_cp05, cd_cp06, cd_cp07, cd_cp08,
			cd_cp09,  cd_cp10, cd_ignore, cd_adName, cd_wpcid, cd_masterid, cd_campaign, cd_url, cd_asid, cd_proxy, cd_status, cd_uniqueid,cd_cutamper)
		(Select  cd_startTime, cd_localTime, cd_outStartTime, cd_endTime, cd_callDuration, cd_outDuration, cd_ani, cd_state, cd_location,
			cd_dnis, cd_bnum, cd_clientId, cd_script, cd_outNum, cd_branch, cd_inChannel, cd_outChannel, cd_message, cd_recording, cd_dtmf,
			cd_dtmfName, cd_callStatus, cd_ap, cd_host, cd_folder, cd_cp01, cd_cp02, cd_cp03, cd_cp04, cd_cp05, cd_cp06, cd_cp07, cd_cp08,
			cd_cp09,  cd_cp10, cd_ignore, cd_adName, cd_wpcid, cd_masterid, cd_campaign, cd_url, cd_asid, cd_proxy, cd_status, cd_uniqueid,cd_cutamper  from cdr where cd_bnum = param_number  AND cd_clientId= param_clientId) ;
	END IF;
	IF param_mode ='delete'  THEN
		
		IF param_ibclientId != '' THEN
			Update inbound set  Client_ID=param_ibclientId WHERE Number=param_number AND Client_ID= param_clientId;
		ELSE
			Update inbound set  Client_ID='5000'  WHERE Number=param_number AND Client_ID= param_clientId;
		END IF;
		
		DELETE FROM cdr WHERE cd_bnum=param_number AND cd_clientId= param_clientId;
	END IF;
	END IF;
ELSE
	IF param_clientId  != '' THEN
		
		
	IF param_mode ='archive'  THEN
		INSERT INTO ib_archive (`Type`, Region, Number, Provider, Client_ID, Client, Terminating_No, Terminating_Service, Requested,
						Provisioned, Decommissioned, AVANSER_ref,  Client_ref, Carrier_ref, Cost_rate, Charge_rate, Bill_source, CFNA,
						calls, Notes, `Status`, Client_Notes)
		(Select  `Type`, Region, Number, Provider, Client_ID, Client, Terminating_No, Terminating_Service, Requested,
						Provisioned, Decommissioned, AVANSER_ref,  Client_ref, Carrier_ref, Cost_rate, Charge_rate, Bill_source, CFNA,
						calls, Notes, `Status`, Client_Notes  from inbound  where  Client_ID= param_clientId ) ;
		
		INSERT INTO cdr_archive (cd_startTime, cd_localTime, cd_outStartTime, cd_endTime, cd_callDuration, cd_outDuration, cd_ani, cd_state, cd_location,
			cd_dnis, cd_bnum, cd_clientId, cd_script, cd_outNum, cd_branch, cd_inChannel, cd_outChannel, cd_message, cd_recording, cd_dtmf,
			cd_dtmfName, cd_callStatus, cd_ap, cd_host, cd_folder, cd_cp01, cd_cp02, cd_cp03, cd_cp04, cd_cp05, cd_cp06, cd_cp07, cd_cp08,
			cd_cp09,  cd_cp10, cd_ignore, cd_adName, cd_wpcid, cd_masterid, cd_campaign, cd_url, cd_asid, cd_proxy, cd_status, cd_uniqueid,cd_cutamper)
		(Select  cd_startTime, cd_localTime, cd_outStartTime, cd_endTime, cd_callDuration, cd_outDuration, cd_ani, cd_state, cd_location,
			cd_dnis, cd_bnum, cd_clientId, cd_script, cd_outNum, cd_branch, cd_inChannel, cd_outChannel, cd_message, cd_recording, cd_dtmf,
			cd_dtmfName, cd_callStatus, cd_ap, cd_host, cd_folder, cd_cp01, cd_cp02, cd_cp03, cd_cp04, cd_cp05, cd_cp06, cd_cp07, cd_cp08,
			cd_cp09,  cd_cp10, cd_ignore, cd_adName, cd_wpcid, cd_masterid, cd_campaign, cd_url, cd_asid, cd_proxy, cd_status, cd_uniqueid,cd_cutamper  from cdr where cd_clientId= param_clientId) ;
	END IF;
	IF param_mode ='delete'  THEN
		
		IF param_ibclientId != '' THEN
			Update inbound set  Client_ID=param_ibclientId WHERE Number=param_number AND Client_ID= param_clientId;
		ELSE
			Update inbound set  Client_ID='5000'  WHERE Number=param_number AND Client_ID= param_clientId;
		END IF;
		
		DELETE FROM cdr WHERE cd_clientId= param_clientId;
	END IF;
	END IF;
END IF;
END;

