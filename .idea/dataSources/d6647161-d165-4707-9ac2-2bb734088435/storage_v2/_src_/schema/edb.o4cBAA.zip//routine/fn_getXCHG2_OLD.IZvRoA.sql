create
    definer = root@`%` function fn_getXCHG2_OLD(telNumber varchar(50), country varchar(2)) returns varchar(20)
    deterministic
BEGIN
	DECLARE x  INT;
	DECLARE MCHLGD VARCHAR(255);
        IF (country != 'AU' AND country !='MY') THEN
		RETURN 0;
	ELSE
          SET x = 12;
      	  WHILE x  >= 3 DO
		IF (country = 'AU') THEN
			SET MCHLGD =(SELECT av_id FROM xchg_AU WHERE av_Ref = (SELECT cli_avRef FROM cli_AU WHERE cli_prefix =SUBSTRING(telNumber,1,x) limit 1) limit 1);
		END IF;
		IF (country = 'MY') THEN
			SET MCHLGD =(SELECT av_id FROM xchg_MY WHERE av_Ref = (SELECT cli_avRef FROM cli_MY WHERE cli_prefix =SUBSTRING(telNumber,1,x) limit 1) limit 1);
		END IF;
		IF  ( MCHLGD != null OR MCHLGD!='') THEN
			SET  x = 0;
			RETURN  MCHLGD;
		ELSE
			SET  x = x - 1;
		END IF;
	  END WHILE;
	END IF;
	RETURN 0;
END;

