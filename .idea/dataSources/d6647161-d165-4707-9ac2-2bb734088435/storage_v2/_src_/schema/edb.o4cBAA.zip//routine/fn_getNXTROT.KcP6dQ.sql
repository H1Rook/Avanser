create
    definer = root@`%` function fn_getNXTROT(clientId int(8), inFolder varchar(20)) returns varchar(20) deterministic
BEGIN
	DECLARE outFolder  VARCHAR(20);
	DECLARE nextone INT;
	DECLARE F00,F01,F02,F03,F04,F05,F06,F07,F08,F09,F10,F11,F12,F13,F14,F15,F16,F17,F18,F19 VARCHAR(20);
	SELECT rt_counter % rt_modulo,rt_f00,rt_f01,rt_f02,rt_f03,rt_f04,rt_f05,rt_f06,rt_f07,rt_f08,rt_f09,rt_f10,rt_f11,rt_f12,rt_f13,rt_f14,rt_f15,rt_f16,rt_f17,rt_f18,rt_f19
		into nextone, F00,F01,F02,F03,F04,F05,F06,F07,F08,F09,F10,F11,F12,F13,F14,F15,F16,F17,F18,F19
		FROM rotator WHERE `rt_clientId` = clientId AND rt_folder= inFolder;
	CASE nextone
		WHEN  0 THEN SET outFolder = F00;
		WHEN  1 THEN SET outFolder = F01;
		WHEN  2 THEN SET outFolder = F02;
		WHEN  3 THEN SET outFolder = F03;
		WHEN  4 THEN SET outFolder = F04;
		WHEN  5 THEN SET outFolder = F05;
		WHEN  6 THEN SET outFolder = F06;
		WHEN  7 THEN SET outFolder = F07;
		WHEN  8 THEN SET outFolder = F08;
		WHEN  9 THEN SET outFolder = F09;
		WHEN 10 THEN SET outFolder = F10;
		WHEN 11 THEN SET outFolder = F11;
		WHEN 12 THEN SET outFolder = F12;
		WHEN 13 THEN SET outFolder = F13;
		WHEN 14 THEN SET outFolder = F14;
		WHEN 15 THEN SET outFolder = F15;
		WHEN 16 THEN SET outFolder = F16;
		WHEN 17 THEN SET outFolder = F17;
		WHEN 18 THEN SET outFolder = F18;
		WHEN 19 THEN SET outFolder = F19;
	ELSE
		SET outFolder = -1;
	END CASE;
	IF isnull(outFolder) THEN
		SET outFolder = -1;
	END IF;
	UPDATE rotator set rt_counter = rt_counter + 1 WHERE `rt_clientId` = clientId AND rt_folder= inFolder;
	RETURN outFolder;
END;

