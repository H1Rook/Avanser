create
    definer = proc@`%` function fn_updateIBService(param_clientId int(8), param_userId varchar(100), param_ibId int(8),
                                                   param_bNum varchar(20), param_serviceName varchar(50),
                                                   param_dnisterm varchar(20), param_campDate date,
                                                   param_decommDate date, param_rateType varchar(8),
                                                   param_cfna varchar(12), param_billsource varchar(10),
                                                   param_provider varchar(30),
                                                   param_avanserref varchar(10)) returns varchar(50) deterministic
BEGIN
IF param_clientId <>'' THEN
	IF  param_decommDate='0000-00-00'  THEN
		SET param_decommDate = NULL;
	END IF;
	
	UPDATE  inbound  SET  Terminating_Service = param_serviceName,
					      Terminating_No = param_dnisterm,
					      CFNA = param_cfna,
					      Bill_source = param_billsource,
					      Type = param_rateType,
					      Provider = param_provider,
					      Provisioned = param_campDate,
					      Decommissioned = param_decommDate,
					      AVANSER_ref = param_avanserref
	WHERE  ID=param_ibId AND Client_ID = param_clientId AND Number = param_bNum;
	
	INSERT INTO ws_auditTrail (at_dateTime, at_source, at_who, at_what, at_result, at_detail )
	Values (now(), 3, param_userId , param_clientId, 'Update Inbound Only Details' , CONCAT('Update Inbound Only  Details',' Service- ',param_serviceName,' Terminating_No -  ',param_dnisterm,' BNUM- ',param_bNum));
	RETURN 'success';
END IF;
END;

