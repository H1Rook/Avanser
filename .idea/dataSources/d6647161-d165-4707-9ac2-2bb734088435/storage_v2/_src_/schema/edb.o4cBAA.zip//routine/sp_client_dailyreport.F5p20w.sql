create
    definer = proc@`%` procedure sp_client_dailyreport(IN mode varchar(10), IN param_scId int,
                                                       IN param_cl_accountNum int, IN param_cl_name varchar(40),
                                                       IN param_sc_sequel varchar(40), IN param_nextrundt date,
                                                       IN param_sc_freq char, IN param_sc_interval varchar(20),
                                                       IN param_sc_subject varchar(120),
                                                       IN param_sc_emailfrom varchar(100),
                                                       IN param_sc_emailto varchar(150),
                                                       IN param_sc_emailcc varchar(150),
                                                       IN param_sc_emailbcc varchar(150),
                                                       IN param_sc_template varchar(100), IN param_ct_text text,
                                                       IN param_custom int, IN param_contractdt date,
                                                       IN param_sc_active int)
BEGIN
DECLARE param_sc_nextRun char(255);
DECLARE param_sc_footer char(255);
DECLARE param_html_template TEXT;
IF mode = 'add' THEN
		IF param_nextrundt<>'' THEN
			SET param_sc_nextRun = CONCAT(param_nextrundt,' 00:01:00');
		ELSE
			SET param_sc_nextRun = CONCAT(DATE_ADD(param_contractdt,INTERVAL 1 DAY),' 00:01:00');
		END IF;
		SET param_sc_footer = 'footer.html';
		IF param_custom>0 THEN
			INSERT INTO content(ct_clientId, ct_name, ct_type, ct_text)
			VALUES(param_cl_accountNum,  param_sc_sequel, 'sql', param_ct_text);
		END IF;
		INSERT INTO sched(sc_clientId, sc_client, sc_active, sc_sequel, sc_nextRun, sc_freq, sc_interval, sc_emailFrom, sc_emailTo, sc_emailCc, sc_emailBcc, sc_template, sc_footer, sc_subject,sc_para01)
		VALUES(param_cl_accountNum, param_cl_name, param_sc_active, param_sc_sequel, param_sc_nextRun, param_sc_freq,  param_sc_interval, param_sc_emailFrom, param_sc_emailto,
			param_sc_emailcc, param_sc_emailbcc, param_sc_template, param_sc_footer, param_sc_subject, param_sc_sequel);
END IF;
IF mode = 'edit' THEN
		IF param_nextrundt<>'' THEN
			SET param_sc_nextRun = CONCAT(param_nextrundt,' 00:01:00');
		ELSE
			SET param_sc_nextRun = CONCAT(DATE_ADD(param_contractdt,INTERVAL 1 DAY),' 00:01:00');
		END IF;
		IF param_ct_text<>'' THEN
			UPDATE content SET ct_text = param_ct_text
			WHERE ct_clientId = param_cl_accountNum
			AND ct_name = param_sc_sequel
			AND ct_type='sql';
		END IF;
		UPDATE sched SET 	sc_freq = param_sc_freq,
				sc_sequel = param_sc_sequel,
				sc_active = param_sc_active,
				sc_template = param_sc_template,
				sc_subject = param_sc_subject,
				sc_emailTo = param_sc_emailto,
				sc_emailCc = param_sc_emailcc,
				sc_emailBcc = param_sc_emailbcc,
				sc_nextRun = param_sc_nextRun
		WHERE sc_id=param_scId AND sc_clientId=param_cl_accountNum;
END IF;
END;

