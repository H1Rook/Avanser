create
    definer = proc@`%` function fn_removesinglequote(p_v1 varchar(255)) returns varchar(255) reads sql data
BEGIN
    return REPLACE(p_v1,"'",'');
END;

