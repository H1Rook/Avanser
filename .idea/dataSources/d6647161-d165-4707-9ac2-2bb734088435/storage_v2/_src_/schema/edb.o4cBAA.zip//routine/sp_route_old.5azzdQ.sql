create
    definer = proc@`%` procedure sp_route_old(IN actionEx char(255), IN mn_id_param char(255), IN mn_dtmfName char(255),
                                              IN mn_target char(255), IN mn_clid char(255), IN mn_emailTo char(255),
                                              IN mn_record char(255), IN mn_notifyAll char(255), IN mn_fax char(255),
                                              IN mn_timeZone char(255), IN mn_clientId_param char(255))
BEGiN
IF actionEx  = 1 THEN
	IF mn_id_param  = 0  THEN
		INSERT INTO menu ( mn_dtmfName, mn_target, mn_clid, mn_emailTo, mn_record, mn_notifyAll, mn_fax, mn_timeZone, mn_clientId, mn_item, mn_action, mn_parent, mn_folder )
		VALUES ( mn_dtmfName, mn_target, mn_clid, mn_emailTo, mn_record, mn_notifyAll, mn_fax, mn_timeZone, mn_clientId_param, -1, 'x',0, '1' );
	ELSE
		UPDATE menu
			SET 	mn_dtmfName	= mn_dtmfName,
				mn_target 	= mn_target,
				mn_clid		= mn_clid,
				mn_emailTo	= mn_emailTo,
				mn_record	= mn_record,
				mn_notifyAll	= mn_notifyAll,
				mn_fax		= mn_fax,
				mn_timeZone	= mn_timeZone
		WHERE mn_id=mn_id_param AND mn_clientId=mn_clientId_param ;
	END IF;
END IF;
IF actionEx  = 2 THEN
	DELETE FROM menu WHERE mn_id=mn_id_param AND mn_clientId=mn_clientId ;
END IF;
END;

