create
    definer = proc@`%` function fn_checkTS(clientId int(8), inFolder varchar(20), whatTime datetime) returns varchar(20)
    deterministic
BEGIN
	DECLARE outFolder, folderA, folderB, folderC, folderD, folderE, folderF, folderG, folderH  VARCHAR(20);
	DECLARE tz, tzo, julo,doyo, todo INT;
	DECLARE W01,W02,W03,W04,W05,W06,W07,SP1,SP2,SP3 VARCHAR(50);
	DECLARE Y2010, Y2011 VARCHAR(366);
	DECLARE folderPointer VARCHAR(1);
	DECLARE loct DATETIME;
	DECLARE lookt VARCHAR(20);
	SELECT `ts_timeZone`, `ts_Y2010`, `ts_Y2011`, `ts_W01`, `ts_W02`, `ts_W03`, `ts_W04`, `ts_W05`, `ts_W06`, `ts_W07`,
		    `ts_SP1`, `ts_SP2`, `ts_SP3`, `ts_folderA`, `ts_folderB`, `ts_folderC`, `ts_folderD`, `ts_folderE`, `ts_folderF`, `ts_folderG`, `ts_folderH`
			INTO tz,Y2010,Y2011,W01,W02,W03,W04,W05,W06,W07,SP1,SP2,SP3,folderA,folderB,folderC,folderD,folderE,folderF,folderG,folderH 
			FROM timeSwitch
		    	WHERE ts_clientId= clientId 
			AND ts_folder = inFolder ;
	SELECT tz_delta INTO tzo FROM timeZone where tz_code = tz;
	SET loct = (select addtime(whatTime, sec_to_time(tzo)));
	SET julo = (select date_format(loct,"%j"));
	IF YEAR(loct) = 2010 THEN
		SET doyo = (select substring(Y2010,julo,1));
	END IF;
	IF YEAR(loct) = 2011 THEN
		SET doyo = (select substring(Y2011,julo,1));
	END IF;
	SET todo = (select (hour(loct) * 2) + (if(minute(loct)>29,1,0)) + 1);
	IF doyo = 0 THEN
		CASE DAYOFWEEK(loct)
			WHEN 1 THEN SET folderPointer = SUBSTRING(W01,todo,1);
			WHEN 2 THEN SET folderPointer = SUBSTRING(W02,todo,1);
			WHEN 3 THEN SET folderPointer = SUBSTRING(W03,todo,1);
			WHEN 4 THEN SET folderPointer = SUBSTRING(W04,todo,1);
			WHEN 5 THEN SET folderPointer = SUBSTRING(W05,todo,1);
			WHEN 6 THEN SET folderPointer = SUBSTRING(W06,todo,1);
			WHEN 7 THEN SET folderPointer = SUBSTRING(W07,todo,1);
		ELSE
			SET folderPointer = -1;
		END CASE;
	ELSE
		CASE doyo
			WHEN 1 THEN SET folderPointer = SUBSTRING(SP1,todo,1);
			WHEN 2 THEN SET folderPointer = SUBSTRING(SP2,todo,1);
			WHEN 3 THEN SET folderPointer = SUBSTRING(SP3,todo,1);
		ELSE
			SET folderPointer = -1;
		END CASE;
	END IF;
	CASE folderPointer
		WHEN 'A' THEN SET outFolder = folderA;
		WHEN 'B' THEN SET outFolder = folderB;
		WHEN 'C' THEN SET outFolder = folderC;
		WHEN 'D' THEN SET outFolder = folderD;
		WHEN 'E' THEN SET outFolder = folderE;
		WHEN 'F' THEN SET outFolder = folderF;
		WHEN 'G' THEN SET outFolder = folderG;
		WHEN 'H' THEN SET outFolder = folderH;
	ELSE
		SET outFolder = -1;
	END CASE;
	SET lookt = (if(julo=0,todo,doyo));
	RETURN outFolder;
END;

