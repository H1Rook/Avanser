create
    definer = proc@`%` procedure sp_dailyreport(IN mode char(255), IN param_cl_accountNum char(255),
                                                IN param_cl_name char(255), IN param_scId int(10),
                                                IN param_sc_subject char(255), IN param_sc_emailto char(255),
                                                IN param_sc_emailcc char(255), IN param_sc_emailbcc char(255),
                                                IN param_nextrundt char(255), IN param_contractdt char(255))
BEGIN
DECLARE param_sc_active char(255);
DECLARE param_sc_sequel char(255);
DECLARE param_sc_nextRun char(255);
DECLARE param_sc_freq char(255);
DECLARE param_sc_emailFrom char(255);
DECLARE param_sc_template char(255);
DECLARE param_sc_footer char(255);
DECLARE param_sc_para01 char(255);
DECLARE check_exists INT;
IF mode = 'add' THEN
		SET param_sc_active = 1;
		SET param_sc_sequel = CONCAT(param_cl_accountNum ,'_daily.sql');
		IF param_nextrundt<>'' THEN
			SET param_sc_nextRun = CONCAT(param_nextrundt,' 00:01:00');
		ELSE
			SET param_sc_nextRun = CONCAT(DATE_ADD(param_contractdt,INTERVAL 1 DAY),' 00:01:00');
		END IF;
		SET param_sc_freq = 'D';
		SET param_sc_emailFrom = 'callmanager@avanser.com.au';
		SET param_sc_template = CONCAT(param_cl_accountNum , '_daily.html');
		SET param_sc_footer = 'footer.html';
		SET param_sc_subject = CONCAT('AVANSER daily call log for ',param_cl_name);
		SET param_sc_para01 = 'CREATE';
		INSERT INTO sched(sc_clientId, sc_client, sc_active, sc_sequel, sc_nextRun, sc_freq, sc_emailFrom, sc_emailTo, sc_emailCc, sc_emailBcc, sc_template, sc_footer, sc_subject, sc_para01)
		VALUES(param_cl_accountNum, param_cl_name, param_sc_active, param_sc_sequel, param_sc_nextRun, param_sc_freq, param_sc_emailFrom, param_sc_emailto,
			param_sc_emailcc, param_sc_emailbcc, param_sc_template, param_sc_footer, param_sc_subject, param_sc_para01);
END IF;
IF mode = 'edit' THEN
		IF param_nextrundt <> '' THEN
			SET param_sc_nextRun = CONCAT(param_nextrundt,' 00:01:00');
		ELSE
			SET param_sc_nextRun = CONCAT(DATE_ADD(param_contractdt,INTERVAL 1 DAY),' 00:01:00');
		END IF;
		UPDATE sched SET 	sc_emailTo = param_sc_emailto,
				sc_emailCc = param_sc_emailcc,
				sc_emailBcc = param_sc_emailbcc,
				sc_nextRun = param_sc_nextRun
		WHERE sc_id=param_scId AND sc_clientId=param_cl_accountNum ;
END IF;
END;

