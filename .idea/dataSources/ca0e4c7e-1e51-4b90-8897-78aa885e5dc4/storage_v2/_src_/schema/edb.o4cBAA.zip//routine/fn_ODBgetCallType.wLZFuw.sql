create
    definer = proc@`%` function fn_ODBgetCallType(param_cd_id varchar(50)) returns varchar(20) deterministic
BEGIN
	DECLARE callFrom  char(255);
	DECLARE callTo  char(255);
	SET callTo = (SELECT left(cd_outNum,2) from cdr where cd_id=param_cd_id);
	SET callFrom = (SELECT  concat('0',left(cd_ani,1)) from cdr where cd_id=param_cd_id);
	IF(callTo='02') THEN
		IF(callFrom!='02') THEN
			UPDATE cdr  SET cd_billCallType='MT' where cd_id=param_cd_id;
		ELSE
			UPDATE cdr  SET cd_billCallType='MM' where cd_id=param_cd_id;
		END IF;
	ELSE
		IF(callFrom!='02' ) THEN
			IF(UCASE(callFrom)='PR' or UCASE(callFrom)='AN' )THEN
				UPDATE cdr  SET cd_billCallType='L' where cd_id=param_cd_id;
			ELSE
				IF(callTo!=callFrom)THEN
					UPDATE cdr  SET cd_billCallType='N' where cd_id=param_cd_id;
				ELSE
					UPDATE cdr  SET cd_billCallType='L' where cd_id=param_cd_id;
				END IF;
			END IF;
		ELSE
			UPDATE cdr  SET cd_billCallType='M' where cd_id=param_cd_id;
		END IF;
	END IF;
	RETURN callFrom;
END;

