create
    definer = proc@`%` procedure SP_Unitel()
BEGIN
set @maxdate=coalesce((select max(Date_Time) from unitel_combined),'');
insert into unitel_combined
(       `ID1`,`EventID`,`Date_Time`,`Duration`,`Originating_Number`,
        `Terminating_Number`,`Charged_Party`,`Price`,`Distance`,`Type_of_Call`,
        `call_type`,`call_charge`)
                (select
                `id`,`Event_ID`,`Date_Time`, `Duration`, `Originating_Number`,
                `Terminating_Number`, `Charged_Party`, `Price`, `Distance`,  `Type_of_Call`,
                `call_type`,  `call_charge`
                from unitel_cdr
                where `Date_Time`>@maxdate);
update unitel_combined
        set ID1=(select ID from unitel_inbound
                where unitel_inbound.EventID=unitel_combined.EventID limit 1);
update unitel_combined
        set Termination = coalesce((select termination from unitel_inbound where
        unitel_inbound.EventID=unitel_combined.EventID limit 1),''),
        Origin = coalesce((select origin from unitel_inbound where
        unitel_inbound.EventID=unitel_combined.EventID limit 1),''),
        CND = coalesce((select CASE left(`PresentationIndicator`,1)
                when 'T' then 'Private'
                ELSE `Asubscriber` END from unitel_inbound where
        unitel_inbound.EventID=unitel_combined.EventID limit 1),'');
set @maxdate = coalesce((SELECT max(`Date_Time`) FROM `unitel_combined` WHERE `EventID`=0),'');
insert into `unitel_combined`
        (`ID2`,`EventID`,`Date_Time`,`Duration`,`Termination`,
        `Originating_Number`,`Terminating_Number`,`Charged_Party`,`Price`,`Distance`,
        `Origin`,`CND`)
        ( select `ID`,0,`Local_Time`,0,`Termination`,
        `Asubscriber`,`Csubscriber`,`Bsubscriber`,0,0,
        `Origin`,CASE left(`presentationindicator`,1)
                when 'T' THEN 'Private'
                ELSE  `Asubscriber` END from `unitel_inbound` where
                `EventID`=0 and unitel_inbound.Local_Time>@maxdate);
END;

