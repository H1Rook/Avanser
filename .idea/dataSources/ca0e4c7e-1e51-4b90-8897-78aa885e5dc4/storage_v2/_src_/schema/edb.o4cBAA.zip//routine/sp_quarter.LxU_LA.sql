create
    definer = root@`%` procedure sp_quarter(IN __clientId__ int(6))
BEGIN

SET @M1 = DATE_FORMAT(DATE_SUB(CURDATE(), INTERVAL 1 MONTH),'%Y%m');
SET @M2 = DATE_FORMAT(DATE_SUB(CURDATE(), INTERVAL 2 MONTH),'%Y%m');
SET @M3 = DATE_FORMAT(DATE_SUB(CURDATE(), INTERVAL 3 MONTH),'%Y%m');

SET @MM1 = DATE_FORMAT(DATE_SUB(CURDATE(), INTERVAL 1 MONTH),'%b %y');
SET @MM2 = DATE_FORMAT(DATE_SUB(CURDATE(), INTERVAL 2 MONTH),'%b %y');
SET @MM3 = DATE_FORMAT(DATE_SUB(CURDATE(), INTERVAL 3 MONTH),'%b %y');

SET @s = CONCAT(
 "SELECT num as 'Advertised Number', ad as 'Ad Source', `Month-1` as 'myM1', `Month-2` as 'myM2', `Month-3` as 'myM3',`Quarter` FROM (
SELECT '' as 'num', '' as 'ad', NULL as 'Month-1', NULL as 'Month-2', NULL as 'Month-3' , NULL as 'Quarter'
UNION
SELECT RIGHT(as_bnum,10) as 'Number', `as_adName` as 'Ad Source',
	(SELECT COUNT(*) FROM `cdr` WHERE `cd_bnum`=`as_bnum` and EXTRACT(YEAR_MONTH FROM `cd_localTime`)= @M1 and `cd_ignore`=0) as Col1,
	(SELECT COUNT(*) FROM `cdr` WHERE `cd_bnum`=`as_bnum` and EXTRACT(YEAR_MONTH FROM `cd_localTime`)= @M2 and `cd_ignore`=0) as Col2,
	(SELECT COUNT(*) FROM `cdr` WHERE `cd_bnum`=`as_bnum` and EXTRACT(YEAR_MONTH FROM `cd_localTime`)= @M3 and `cd_ignore`=0) as Col3,
	(SELECT COUNT(*) FROM `cdr` WHERE `cd_bnum`=`as_bnum` and EXTRACT(YEAR_MONTH FROM `cd_localTime`) BETWEEN @M3 and @M1) as Col4
FROM `adSource` WHERE `as_clientId`= ", __clientId__ , ") as `xxx` ORDER BY  `Quarter` DESC");

SET @s = REPLACE (@s,'myM1',@MM1);
SET @s = REPLACE (@s,'myM2',@MM2);
SET @s = REPLACE (@s,'myM3',@MM3);

PREPARE stmt From @s;
EXECUTE stmt;

END;

