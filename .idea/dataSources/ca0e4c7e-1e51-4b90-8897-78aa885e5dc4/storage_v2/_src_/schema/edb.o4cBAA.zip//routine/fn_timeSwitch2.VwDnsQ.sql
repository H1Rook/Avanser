create
    definer = proc@`%` function fn_timeSwitch2(clientId int(8), inFolder varchar(20)) returns varchar(20) deterministic
BEGIN
	DECLARE myMonth VARCHAR(2);
	DECLARE fullMonth, M01,M02,M03,M04,M05,M06,M07,M08,M09,M10,M11,M12 VARCHAR(31);
	DECLARE TID, tz, tzo, todo INT;
	DECLARE D01,D02,D03,D04,D05,D06,D07,D08,D09 VARCHAR(50);
	DECLARE loct DATETIME;
	DECLARE dayType, outCode VARCHAR(1);
	DECLARE weekDays VARCHAR(7);
	DECLARE result, OA,OB,OC,OD,OE,OF,OG,OH VARCHAR(20);

	
	SELECT mt_id, mt_timeZone, mt_week, mt_day01,mt_day02,mt_day03,mt_day04,mt_day05,mt_day06,mt_day07,mt_day08,mt_day09,
           mt_month01,mt_month02,mt_month03,mt_month04,mt_month05,mt_month06,mt_month07,mt_month08,mt_month09,mt_month10,mt_month11,mt_month12,
	       mt_outA,mt_outB,mt_outC,mt_outD,mt_outE,mt_outF,mt_outG,mt_outH
      INTO TID, tz, weekDays, D01,D02,D03,D04,D05,D06,D07,D08,D09,
           M01,M02,M03,M04,M05,M06,M07,M08,M09,M10,M11,M12,
	       OA,OB,OC,OD,OE,OF,OG,OH
      FROM `menu_time`
      WHERE `mt_clientId`=clientId
        AND `mt_folder`=inFolder;

	
	SELECT tz_delta INTO tzo FROM timeZone where tz_code = tz;
	SET loct = (select addtime(now(), sec_to_time(tzo)));
	
	
	CASE DATE_FORMAT(loct,'%m')
		WHEN 01 THEN SET dayType = SUBSTRING(M01,DATE_FORMAT(loct,'%e'),1);
		WHEN 02 THEN SET dayType = SUBSTRING(M02,DATE_FORMAT(loct,'%e'),1);
		WHEN 03 THEN SET dayType = SUBSTRING(M03,DATE_FORMAT(loct,'%e'),1);
		WHEN 04 THEN SET dayType = SUBSTRING(M04,DATE_FORMAT(loct,'%e'),1);
		WHEN 05 THEN SET dayType = SUBSTRING(M05,DATE_FORMAT(loct,'%e'),1);
		WHEN 06 THEN SET dayType = SUBSTRING(M06,DATE_FORMAT(loct,'%e'),1);
		WHEN 07 THEN SET dayType = SUBSTRING(M07,DATE_FORMAT(loct,'%e'),1);
		WHEN 08 THEN SET dayType = SUBSTRING(M08,DATE_FORMAT(loct,'%e'),1);
		WHEN 09 THEN SET dayType = SUBSTRING(M09,DATE_FORMAT(loct,'%e'),1);
		WHEN 10 THEN SET dayType = SUBSTRING(M10,DATE_FORMAT(loct,'%e'),1);
		WHEN 11 THEN SET dayType = SUBSTRING(M11,DATE_FORMAT(loct,'%e'),1);
		WHEN 12 THEN SET dayType = SUBSTRING(M12,DATE_FORMAT(loct,'%e'),1);
	ELSE
		RETURN CONCAT('error-month.',DATE_FORMAT(loct,'%m'));
	END CASE;

	
	IF dayType = '0' THEN
		SET dayType = SUBSTRING(weekDays,DATE_FORMAT(loct,'%w')+1,1);

	END IF;
	
	SET todo = (select (hour(loct) * 2) + (if(minute(loct)>29,1,0)) + 1);

	CASE dayType
		WHEN 1 THEN SET outCode = SUBSTRING(D01,todo,1);
		WHEN 2 THEN SET outCode = SUBSTRING(D02,todo,1);
		WHEN 3 THEN SET outCode = SUBSTRING(D03,todo,1);
		WHEN 4 THEN SET outCode = SUBSTRING(D04,todo,1);
		WHEN 5 THEN SET outCode = SUBSTRING(D05,todo,1);
		WHEN 6 THEN SET outCode = SUBSTRING(D06,todo,1);
		WHEN 7 THEN SET outCode = SUBSTRING(D07,todo,1);
		WHEN 8 THEN SET outCode = SUBSTRING(D08,todo,1);
		WHEN 9 THEN SET outCode = SUBSTRING(D09,todo,1);
	ELSE
		RETURN CONCAT('error-day.',dayType);
	END CASE;

	CASE outCode
		WHEN 'A' THEN SET result = OA;
		WHEN 'B' THEN SET result = OB;
		WHEN 'C' THEN SET result = OC;
		WHEN 'D' THEN SET result = OD;
		WHEN 'E' THEN SET result = OE;
		WHEN 'F' THEN SET result = OF;
		WHEN 'G' THEN SET result = OG;
		WHEN 'H' THEN SET result = OH;
	ELSE
		RETURN CONCAT('error-char.',outCode);
	END CASE;

	IF result IS NULL OR result = '' THEN
		RETURN 'error-noResult';
	END IF;

	RETURN result;

END;

