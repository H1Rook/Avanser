create
    definer = webApp@`%` procedure sp_decommission(IN param_number char(255), IN param_clientId char(255))
BEGIN
DECLARE gmembers  char(255);
IF param_number  != '' THEN
	
	IF param_clientId  != '' THEN
		
		
		DELETE FROM dispatcher WHERE dp_clientId=param_clientId AND dp_bnum=param_number ;
		
		UPDATE inbound SET  Decommissioned=NOW() WHERE Client_ID=param_clientId AND Number=param_number ;
		
		DELETE FROM portal_clientbnum WHERE  cb_bnum=param_number ;
		
		SET gmembers = ( Select as_id  FROM adSource WHERE as_clientId=param_clientId AND as_bnum=param_number);
		
		DELETE FROM groups where gr_gmember in (gmembers)  AND gr_clientId like CONCAT(param_clientId,'%') ;
		
		DELETE FROM adSource WHERE as_clientId=param_clientId AND as_bnum=param_number  ;
		
	END IF;
ELSE
	
	IF param_clientId  != '' THEN
		
		
		DELETE FROM dispatcher WHERE dp_clientId=param_clientId;
		
		UPDATE inbound SET  Decommissioned=NOW() WHERE Client_ID=param_clientId;
		
		DELETE FROM portal_clientbnum WHERE  cb_clientId like CONCAT(param_clientId,'%') ;
		
		SET gmembers = ( Select GROUP_CONCAT(CAST(as_id AS CHAR))  FROM adSource WHERE as_clientId=param_clientId);
		
		DELETE FROM groups where gr_gmember in (gmembers)  AND gr_clientId like CONCAT(param_clientId,'%') ;
		
		DELETE FROM adSource WHERE as_clientId=param_clientId ;
		
		DELETE FROM cdr_notes WHERE cdh_clientId= param_clientId;
		
		DELETE FROM rotator WHERE rt_clientId=param_clientId ;
		
		DELETE FROM sched WHERE sc_clientId=param_clientId ;
	END IF;
END IF;
END;

