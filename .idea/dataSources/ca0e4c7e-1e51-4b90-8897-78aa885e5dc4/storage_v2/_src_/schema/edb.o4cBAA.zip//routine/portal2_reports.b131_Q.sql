create
    definer = proc@`%` procedure portal2_reports(IN Pcontroller char(40), IN PclientIdx char(20),
                                                 IN Pstart_date char(20), IN Pend_date char(20),
                                                 IN Pclientaccessflag char(20), IN Ptypesearch char(20), IN Pads text,
                                                 IN Pgname char(40))
BEGIN
	IF Pcontroller = 'reportads' THEN
		IF Ptypesearch = 'ad' THEN
			
			SELECT REPLACE(as_adName, '-', '' ) AS Name, 
				count(cd_id) AS Leads
			FROM portal_clientbnum, cdr, adSource
			WHERE cb_clientIdx =PclientIdx
				AND cb_accessflag	= Pclientaccessflag
				AND cb_bnum 	= cd_bnum
				AND DATE_FORMAT(cd_localTime, '%Y-%m-%d') >=Pstart_date
				AND DATE_FORMAT(cd_localTime, '%Y-%m-%d') <=Pend_date
				AND as_bnum	= cd_bnum
				AND as_id IN (Pads)
			GROUP BY Name ORDER BY Leads DESC;
		END IF;
	END IF;
END;

