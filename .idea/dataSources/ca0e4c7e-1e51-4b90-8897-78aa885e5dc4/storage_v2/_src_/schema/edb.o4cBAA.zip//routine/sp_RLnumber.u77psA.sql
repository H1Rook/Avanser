create
    definer = proc@`%` procedure sp_RLnumber(IN param_action char(255), IN param_as_id char(255),
                                             IN param_as_adName char(255), IN param_destination char(255),
                                             IN param_published char(255), IN param_timeout char(255),
                                             IN param_as_rlwocID char(255), IN param_as_masterID char(255),
                                             IN param_as_proxy char(255), IN param_timeZone char(255),
                                             IN param_record char(255))
BEGiN
DECLARE confHost  char(255);
DECLARE confScript  char(255);
DECLARE confClient  char(255);
DECLARE confClientID  char(255);
DECLARE confFolder  char(255);
DECLARE confTerminatingNo  char(255);
DECLARE stbnum char(255);
SET confHost = 'VCS1';
SET confScript = 'autoattendant';
SET confClient = 'Reach Local';
SET confClientID = 6094;
	IF param_action='1' THEN
		SET stbnum = (SELECT as_bnum FROM adSource WHERE as_id=param_as_id);
		SET confTerminatingNo = ( SELECT Terminating_No FROM inbound WHERE Number=stbnum AND  client_ID=confClientID );
		UPDATE adSource SET  as_adName=param_as_adName, as_rlwpcID=param_as_rlwocID, as_masterID=param_as_masterID, as_proxy=param_as_proxy
		WHERE as_clientId=confClientID AND as_id=param_as_id;
		UPDATE menu  SET mn_dtmfName=param_as_adName, mn_target=param_destination, mn_record=param_record, mn_timeOut=param_timeout, mn_timeZone=param_timeZone
		WHERE mn_clientId=confClientID AND mn_folder=(SELECT dp_folder from dispatcher where dp_bnum=stbnum );
	END IF;
	IF param_action='2' THEN
		SET confFolder = (SELECT max(mn_folder)+1 FROM menu WHERE mn_clientId=confClientID);
		IF isNULL(confFolder) THEN
			SET confFolder = (SELECT concat(confClientID,'0001'));
		END IF;
		UPDATE inbound SET client_ID=confClientID, client=confClient,Terminating_Service=confClient, Requested=now(), Provisioned=now(), Decommissioned=NULL, Bill_Source='CDR', cfna=''  WHERE Number=param_published;
		SET confTerminatingNo = ( SELECT Terminating_No FROM inbound WHERE Number=param_published AND  client_ID=confClientID );
		INSERT INTO adSource ( as_clientId, as_adName, as_bnum, as_campaignStart, as_rlwpcID, as_masterID, as_proxy)
		VALUES (confClientID, param_as_adName, param_published, now(), param_as_rlwocID, param_as_masterID, param_as_proxy );
		INSERT INTO dispatcher( dp_bnum,dp_dnis,dp_host,dp_script,dp_clientId, dp_folder)
		VALUES (param_published, confTerminatingNo, confHost, confScript, confClientID, confFolder);
		IF (isNULL(param_timeout) or LENGTH(TRIM(param_timeout))=0) THEN
			SET param_timeout = 0;
		END IF;
		IF (isNULL(param_record) or LENGTH(TRIM(param_record))=0) THEN
			SET param_record = 0;
		END IF;
		INSERT INTO menu ( mn_clientId, mn_folder, mn_agentId, mn_parent, mn_item, mn_dtmfName, mn_action, mn_noWait, mn_target, mn_greeting, mn_record, mn_timeOut, mn_timeZone)
		VALUES ( confClientID, confFolder, confFolder,0,-1, param_as_adName,'x',1, param_destination, 'not_available.wav', param_record, param_timeout , param_timeZone );
		INSERT INTO portal_clientbnum (cb_clientId, cb_bnum, cb_clientIdx, cb_accessflag)
		VALUES (confClientID, param_published, confClientID, '9999');
	END IF;
	IF param_action='3' THEN
		SET stbnum = (SELECT as_bnum FROM adSource WHERE as_id=param_as_id);
		SET confFolder = (SELECT dp_folder FROM dispatcher WHERE  dp_clientId=confClientID and dp_bnum=stbnum);
		DELETE FROM portal_clientbnum where cb_clientid=confClientID AND cb_bnum=stbnum;
		DELETE FROM dispatcher where dp_clientId=confClientID AND dp_bnum=stbnum;
		DELETE FROM adSource where as_clientId=confClientID AND as_bnum=stbnum;
		DELETE FROM menu  where mn_clientId=confClientID AND mn_folder=confFolder;
		UPDATE inbound set decommissioned=now() where client_ID=confClientID and Number=stbnum;
	END IF;
END;

