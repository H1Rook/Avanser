create
    definer = proc@`%` function fn_createCustomService(client_id int(8), sessionUser varchar(50), inboundId int(8),
                                                       InbNumber varchar(20), AdSource varchar(50), pvDate date,
                                                       param_wpcId int(10), param_masterId int(10),
                                                       param_proxytag varchar(40), param_mn_target varchar(100),
                                                       param_mn_record int(2), param_subject varchar(100),
                                                       param_emailFrom varchar(100), param_emailTo varchar(255),
                                                       param_emailCc varchar(255), param_emailBcc varchar(255),
                                                       param_mn_timeout int(4), param_timezone int(4),
                                                       param_customVox int(2), param_whisper varchar(50),
                                                       param_asnotes varchar(200), param_template varchar(50),
                                                       param_templateId int(10)) returns varchar(20) deterministic
BEGIN
DECLARE confHost  VARCHAR(10);
DECLARE confdp_dnis VARCHAR(50);
DECLARE count_adsource Integer(5);
DECLARE checkdnis VARCHAR(50);
DECLARE confFolder VARCHAR(20);
DECLARE checkfolder VARCHAR(20);
DECLARE checkadsource VARCHAR(20);
DECLARE conf_country VARCHAR(2);

	
	SET checkadsource = (SELECT COUNT(*) FROM adSource WHERE as_clientId=client_id AND as_adName=AdSource);

	IF (checkadsource>0) THEN
		RETURN 'failedadsource';
	ELSE
		SET confFolder = (SELECT max(mn_folder + 1) AS next FROM menu WHERE mn_clientId=client_id);
        	IF isNULL(confFolder) THEN
            	SET confFolder = (SELECT concat(confClientID,'0001'));
        	END IF;

		IF(param_template='')THEN
			SET param_template='autoattendant.html';
		END IF;

		IF(param_subject='') THEN
			SET param_subject = 'Missed Call. From [ani] to [bnum]';
		END IF;

		SET checkfolder = (SELECT COUNT(*) FROM menu WHERE mn_clientId=client_id AND mn_folder=confFolder);

		IF checkfolder=0 THEN
			INSERT INTO menu(mn_clientId, mn_folder, mn_agentId, mn_parent, mn_item, mn_dtmfName, mn_action, mn_noWait, mn_route, mn_default, mn_target, mn_forward, mn_clid, mn_customVox,
							mn_greeting, mn_subject, mn_emailFrom, mn_emailTo, mn_emailCc, mn_emailBcc, mn_template, mq_mobile, mn_sms, mn_whisper, mn_ack, mn_prompt, mn_submenu, mn_notifyAll,
							mn_record, mn_timeOut, mn_timeZone, mn_ap, mn_fax, mn_auxFolder, mn_url, mn_filter, mn_ignore, fws)
			SELECT client_id, confFolder, confFolder, 0, -1, AdSource, 'xfr', mn_noWait, mn_route, mn_default, param_mn_target, mn_forward, mn_clid,param_customVox,
					mn_greeting, param_subject, param_emailFrom, param_emailTo, param_emailCc, param_emailBcc, param_template, mq_mobile, mn_sms, param_whisper,mn_ack, mn_prompt, mn_submenu, mn_notifyAll,
					param_mn_record, param_mn_timeout, param_timezone, mn_ap, mn_fax, mn_auxFolder, mn_url, mn_filter, mn_ignore, fws
				FROM menu
			WHERE mn_id= param_templateId;
		END IF;

		SET confHost 	= ( SELECT AVANSER_ref FROM inbound WHERE  ID = inboundId );
		SET confdp_dnis = ( SELECT Terminating_No FROM inbound WHERE  ID = inboundId );
		SET checkdnis = (SELECT COUNT(*) FROM dispatcher WHERE dp_dnis=confdp_dnis);
		SET conf_country = ( SELECT in_country FROM inbound WHERE  ID = inboundId );

		IF(checkdnis>0) THEN
			RETURN 'failed2';
		ELSE

			INSERT INTO dispatcher (dp_clientId, dp_bnum, dp_dnis, dp_country, dp_host, dp_script, dp_folder, dp_comments)
			   	VALUES (client_id, InbNumber, confdp_dnis, conf_country, confHost, 'autoattendant', confFolder, AdSource);

			UPDATE inbound SET Client_ID	= client_id,
				 Terminating_Service = AdSource,
				 Requested	= NOW(),
				 Provisioned	= pvDate,
				 Decommissioned = null
			WHERE	ID = inboundId;

			INSERT INTO adSource (as_clientId , as_adName, as_bnum, as_cost, as_campaignStart, as_rlwpcID, as_masterID, as_proxy, as_notes)
			   	VALUES (client_id, AdSource, InbNumber , 1, pvDate, param_wpcId, param_masterId, param_proxytag, param_asnotes);

			INSERT INTO portal_clientbnum (cb_clientId, cb_bnum, cb_clientIdx, cb_accessflag)
			   	VALUES (client_id, InbNumber, client_id, '9999');

			INSERT INTO ws_auditTrail (at_dateTime, at_source, at_who, at_what, at_result, at_detail ) Values (now(), 3, sessionUser, client_id, 'New Service', InbNumber);

			RETURN 'success';
		END IF;
	END IF;
END;

