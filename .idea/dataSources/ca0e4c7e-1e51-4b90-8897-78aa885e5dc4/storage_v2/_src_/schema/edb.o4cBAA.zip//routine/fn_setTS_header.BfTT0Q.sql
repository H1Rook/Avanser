create
    definer = proc@`%` function fn_setTS_header(clientId int(8), inFolder varchar(20), tsName varchar(40),
                                                timeZone int(2)) returns varchar(20) deterministic
BEGIN
	DECLARE kount INT;
	SELECT count(*) INTO kount FROM timeSwitch
		    WHERE ts_clientId= clientId AND ts_folder = inFolder ;
	IF kount =0 THEN
		RETURN 'Error: entry does not exist!';
	ELSE
		UPDATE timeSwitch
			SET 	`ts_clientId` = clientId,
				`ts_folder` = inFolder,
				`ts_name`=tsName,
				`ts_timeZone`=timeZone
		WHERE ts_clientId= clientId AND ts_folder = inFolder ;
	END IF;
	RETURN 'ok';
END;

