create
    definer = proc@`%` function fn_getLOCN2(telNumber varchar(50), country varchar(2)) returns varchar(20) deterministic
BEGIN
	DECLARE x  INT;
	DECLARE MCHLGD VARCHAR(255);
        SET x = 12;
	IF (country = 'AU') THEN
		IF (SUBSTRING(telNumber,1,2) != '61') THEN
			SET telNumber = CONCAT('61',SUBSTRING(telnumber,1,50));
		END IF;
	END IF;
	WHILE x  >= 3 DO
		IF (country = 'AU') THEN
			SET MCHLGD =(SELECT cli_id FROM cli_AU WHERE cli_prefix =SUBSTRING(telNumber,1,x) limit 1);
		ELSEIF (country = 'MY') THEN
			SET MCHLGD =(SELECT cli_id FROM cli_MY WHERE cli_prefix =SUBSTRING(telNumber,1,x) limit 1);
		ELSE
			RETURN 0;
		END IF;
		IF  ( MCHLGD != null OR MCHLGD!='') THEN
			SET  x = 0;
			RETURN  (MCHLGD);
		ELSE
			SET  x = x - 1;
		END IF;
	END WHILE;
	RETURN 0;
END;

