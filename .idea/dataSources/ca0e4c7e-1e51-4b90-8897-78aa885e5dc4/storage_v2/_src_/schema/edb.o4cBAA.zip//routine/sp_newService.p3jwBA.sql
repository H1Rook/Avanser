create
    definer = proc@`%` procedure sp_newService(IN client_id char(255), IN UserId char(255), IN AdSource char(255),
                                               IN InbNumber char(255), IN Folder char(255), IN Target char(255),
                                               IN script char(255), IN inboundId char(255), IN pvDate char(255))
BEGIN
DECLARE confHost  char(255);
DECLARE confdp_dnis char(255);
	SET confHost 		= ( SELECT AVANSER_ref FROM inbound WHERE  ID = inboundId );
	SET confdp_dnis 	= ( SELECT Terminating_No FROM inbound WHERE  ID = inboundId );
	UPDATE inbound SET Client_ID	= client_id,
					  Terminating_Service = AdSource,
					  Requested	= NOW(),
					  Provisioned	= pvDate,
					  Decommissioned = null
				WHERE	ID = inboundId;
	INSERT INTO dispatcher (dp_clientId, dp_bnum, dp_dnis, dp_host, dp_script, dp_folder, dp_comments )
			   VALUES (client_id, InbNumber, confdp_dnis, confHost, script, Folder, AdSource);
	INSERT INTO adSource (as_clientId , as_adName, as_bnum, as_cost, as_campaignStart)
			   VALUES (client_id, AdSource, InbNumber , 1, pvDate );
	INSERT INTO portal_clientbnum (cb_clientId, cb_bnum, cb_clientIdx, cb_accessflag)
			   VALUES (client_id, InbNumber, client_id, '9999');
	INSERT INTO ws_auditTrail (at_dateTime, at_source, at_who, at_what, at_result, at_detail ) Values (now(), 3, UserId, client_id, 'New Number', InbNumber );
END;

