create
    definer = proc@`%` function fn_createRLNZService(client_id int(8), sessionUser varchar(50), inboundId int(8),
                                                     InbNumber varchar(20), AdSource varchar(50), pvDate date,
                                                     wpcId int(10), masterId int(10)) returns varchar(20) deterministic
BEGIN
DECLARE confHost  VARCHAR(10);
DECLARE confdp_dnis VARCHAR(50);
DECLARE count_adsource Integer(5);
DECLARE checkdnis VARCHAR(50);
DECLARE confFolder VARCHAR(20);
DECLARE checkfolder VARCHAR(20);
	
	SET confFolder = (SELECT max(mn_folder + 1) AS next FROM menu WHERE mn_clientId=client_id AND mn_folder BETWEEN 609400000 AND 609499999);
        IF isNULL(confFolder) THEN
            SET confFolder = (SELECT concat(confClientID,'0001'));
        END IF;
	
	SET checkfolder = (SELECT COUNT(*) FROM menu WHERE mn_clientId=client_id AND mn_folder=confFolder);
	IF checkfolder=0 THEN
		
		INSERT INTO menu (mn_clientId, mn_folder, mn_agentId, mn_parent, mn_item, mn_dtmfName, mn_action, mn_noWait, mn_target, mn_greeting, mn_record, mn_timeOut, mn_timeZone)
	        VALUES  (client_id, confFolder, confFolder,0,-1, AdSource,'xfr',1, '+64-0', 'longbusy.wav', 0, 30 , 64);
	END IF;
	SET confHost 	= ( SELECT AVANSER_ref FROM inbound WHERE  ID = inboundId );
	SET confdp_dnis = ( SELECT Terminating_No FROM inbound WHERE  ID = inboundId );
	SET checkdnis = (SELECT COUNT(*) FROM dispatcher WHERE dp_dnis=confdp_dnis);
	IF(checkdnis>0) THEN
		RETURN 'failed2';
	ELSE
		
		INSERT INTO dispatcher (dp_clientId, dp_bnum, dp_dnis, dp_country, dp_host, dp_script, dp_folder, dp_comments)
			   VALUES (client_id, InbNumber, confdp_dnis, 'NZ', confHost, 'autoattendant', confFolder, AdSource);
		
		UPDATE inbound SET Client_ID	= client_id,
				  Terminating_Service = AdSource,
				  Provisioned	= pvDate,
				   in_country = 'NZ',
				  Decommissioned = null
		WHERE	ID = inboundId;
		
		INSERT INTO adSource (as_clientId , as_adName, as_bnum, as_cost, as_campaignStart,as_rlwpcID,as_masterID)
			   VALUES (client_id, AdSource, InbNumber , 0, pvDate, wpcId, masterId);
		
		INSERT INTO portal_clientbnum (cb_clientId, cb_bnum, cb_clientIdx, cb_accessflag)
			   VALUES (client_id, InbNumber, client_id, '9999');
		
		INSERT INTO ws_auditTrail (at_dateTime, at_source, at_who, at_what, at_result, at_detail ) Values (now(), 3, sessionUser, client_id, 'New Service', InbNumber);
		
		INSERT INTO RLadSource (rlas_clientId, rlas_adName, rlas_bnum, rlas_wpcID, rlas_masterID) VALUES (client_id, AdSource, InbNumber, wpcId, masterId) ;
		RETURN InbNumber;
	END IF;
END;

